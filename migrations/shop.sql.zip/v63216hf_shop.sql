-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 12 2022 г., 16:38
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `v63216hf_shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `areas`
--
-- Создание: Фев 22 2022 г., 07:59
--

DROP TABLE IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` float NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `areas`
--

INSERT INTO `areas` (`id`, `name`, `trans`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'Alibaba', 'alibaba', 2, '2022-02-22 07:11:58', '2022-03-09 10:19:08'),
(2, 'AliExpress', 'aliexpress', 2.25, '2022-02-22 07:12:07', '2022-03-09 10:19:07'),
(3, 'eBay', 'ebay', 3, '2022-02-22 07:12:14', '2022-03-09 10:19:05'),
(4, 'Rozetka', 'rozetka', 4, '2022-02-22 07:12:29', '2022-03-09 10:19:01'),
(5, 'Prom', 'prom', 5, '2022-02-22 07:12:36', '2022-03-09 10:19:00'),
(6, 'Bigl', 'bigl', 6, '2022-02-22 07:12:50', '2022-03-09 10:19:00'),
(7, 'OLX', 'olx', 7, '2022-02-22 07:12:56', '2022-03-09 10:18:52'),
(10, 'Amazon', 'amazon', 1, '2022-03-06 18:26:47', '2022-03-09 10:19:08');

-- --------------------------------------------------------

--
-- Структура таблицы `cron`
--
-- Создание: Фев 08 2022 г., 09:36
--

DROP TABLE IF EXISTS `cron`;
CREATE TABLE `cron` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `launch_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `cron`
--

INSERT INTO `cron` (`id`, `name`, `launch_at`, `created_at`, `updated_at`) VALUES
(1, 'nameCronTask', '2022-02-10 14:53:34', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `currencies`
--
-- Создание: Мар 05 2022 г., 20:31
--

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` float NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `currencies`
--

INSERT INTO `currencies` (`id`, `name`, `short`, `trans`, `sort`, `created_at`, `updated_at`) VALUES
(1, NULL, 'грн', 'currency', 1, '2022-03-15 18:47:47', NULL),
(2, NULL, 'обмен', 'currency', 2, '2022-03-15 18:47:47', NULL),
(3, NULL, '$', 'currency', 3, '2022-03-17 15:00:38', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `fields`
--
-- Создание: Мар 05 2022 г., 20:31
--

DROP TABLE IF EXISTS `fields`;
CREATE TABLE `fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `typefield_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `trans` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` float NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `fields`
--

INSERT INTO `fields` (`id`, `typefield_id`, `product_id`, `name`, `value`, `content`, `trans`, `sort`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 1, '2022-03-15 18:47:47', NULL),
(2, 1, 1, 'price_info', 'Договорная', NULL, 'price_info', 2, '2022-03-15 18:47:47', NULL),
(3, 1, 1, 'top', 'yes', NULL, 'top', 3, '2022-03-15 18:47:47', NULL),
(4, 1, 1, 'location', 'Полтава', NULL, 'location', 4, '2022-03-15 18:47:47', NULL),
(5, 1, 1, 'add_time', '12  март', NULL, 'add_time', 5, '2022-03-15 18:47:47', NULL),
(6, 1, 2, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 6, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(7, 1, 2, 'top', 'yes', NULL, 'top', 7, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(8, 1, 2, 'location', 'Ратно', NULL, 'location', 8, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(9, 1, 2, 'add_time', 'Сегодня 12:32', NULL, 'add_time', 9, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(10, 1, 3, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 10, '2022-03-15 18:47:47', NULL),
(11, 1, 3, 'price_info', 'Договорная', NULL, 'price_info', 11, '2022-03-15 18:47:47', NULL),
(12, 1, 3, 'top', 'yes', NULL, 'top', 12, '2022-03-15 18:47:47', NULL),
(13, 1, 3, 'location', 'Снятын', NULL, 'location', 13, '2022-03-15 18:47:47', NULL),
(14, 1, 3, 'add_time', '12  март', NULL, 'add_time', 14, '2022-03-15 18:47:47', NULL),
(15, 1, 4, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 15, '2022-03-15 18:47:47', NULL),
(16, 1, 4, 'price_info', 'Договорная', NULL, 'price_info', 16, '2022-03-15 18:47:47', NULL),
(17, 1, 4, 'top', 'yes', NULL, 'top', 17, '2022-03-15 18:47:47', NULL),
(18, 1, 4, 'location', 'Белая Церковь', NULL, 'location', 18, '2022-03-15 18:47:47', NULL),
(19, 1, 4, 'add_time', 'Вчера 09:28', NULL, 'add_time', 19, '2022-03-15 18:47:47', NULL),
(20, 1, 5, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 20, '2022-03-15 18:47:47', NULL),
(21, 1, 5, 'price_info', 'Договорная', NULL, 'price_info', 21, '2022-03-15 18:47:47', NULL),
(22, 1, 5, 'top', 'yes', NULL, 'top', 22, '2022-03-15 18:47:47', NULL),
(23, 1, 5, 'location', 'Тернополь', NULL, 'location', 23, '2022-03-15 18:47:47', NULL),
(24, 1, 5, 'add_time', '13  март', NULL, 'add_time', 24, '2022-03-15 18:47:47', NULL),
(25, 1, 6, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 25, '2022-03-15 18:47:47', NULL),
(26, 1, 6, 'location', 'Луцк', NULL, 'location', 26, '2022-03-15 18:47:47', NULL),
(27, 1, 6, 'add_time', 'Сегодня 20:40', NULL, 'add_time', 27, '2022-03-15 18:47:47', NULL),
(28, 1, 7, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 28, '2022-03-15 18:47:47', NULL),
(29, 1, 7, 'price_info', 'Договорная', NULL, 'price_info', 29, '2022-03-15 18:47:47', NULL),
(30, 1, 7, 'location', 'Кагарлык', NULL, 'location', 30, '2022-03-15 18:47:47', NULL),
(31, 1, 7, 'add_time', 'Сегодня 20:33', NULL, 'add_time', 31, '2022-03-15 18:47:47', NULL),
(32, 1, 8, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 32, '2022-03-15 18:47:47', NULL),
(33, 1, 8, 'price_info', 'Договорная', NULL, 'price_info', 33, '2022-03-15 18:47:47', NULL),
(34, 1, 8, 'location', 'Днепр, Амур-Нижнеднепровский', NULL, 'location', 34, '2022-03-15 18:47:47', NULL),
(35, 1, 8, 'add_time', 'Сегодня 20:31', NULL, 'add_time', 35, '2022-03-15 18:47:47', NULL),
(36, 1, 9, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 36, '2022-03-15 18:47:47', NULL),
(37, 1, 9, 'location', 'Шепетовка', NULL, 'location', 37, '2022-03-15 18:47:47', NULL),
(38, 1, 9, 'add_time', 'Сегодня 20:26', NULL, 'add_time', 38, '2022-03-15 18:47:47', NULL),
(39, 1, 10, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 39, '2022-03-15 18:47:47', NULL),
(40, 1, 10, 'location', 'Вишневое', NULL, 'location', 40, '2022-03-15 18:47:47', NULL),
(41, 1, 10, 'add_time', 'Сегодня 20:21', NULL, 'add_time', 41, '2022-03-15 18:47:47', NULL),
(42, 1, 11, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 42, '2022-03-15 18:47:47', NULL),
(43, 1, 11, 'location', 'Луганск, Жовтневый', NULL, 'location', 43, '2022-03-15 18:47:47', NULL),
(44, 1, 11, 'add_time', 'Сегодня 20:08', NULL, 'add_time', 44, '2022-03-15 18:47:47', NULL),
(45, 1, 12, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 45, '2022-03-15 18:47:47', NULL),
(46, 1, 12, 'location', 'Зборов', NULL, 'location', 46, '2022-03-15 18:47:47', NULL),
(47, 1, 12, 'add_time', 'Сегодня 20:08', NULL, 'add_time', 47, '2022-03-15 18:47:47', NULL),
(48, 1, 13, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 48, '2022-03-15 18:47:47', NULL),
(49, 1, 13, 'price_info', 'Договорная', NULL, 'price_info', 49, '2022-03-15 18:47:47', NULL),
(50, 1, 13, 'location', 'Старява', NULL, 'location', 50, '2022-03-15 18:47:47', NULL),
(51, 1, 13, 'add_time', 'Сегодня 20:05', NULL, 'add_time', 51, '2022-03-15 18:47:47', NULL),
(52, 1, 14, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 52, '2022-03-15 18:47:47', NULL),
(53, 1, 14, 'location', 'Тернополь', NULL, 'location', 53, '2022-03-15 18:47:47', NULL),
(54, 1, 14, 'add_time', 'Сегодня 20:04', NULL, 'add_time', 54, '2022-03-15 18:47:47', NULL),
(55, 1, 15, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 55, '2022-03-15 18:47:47', NULL),
(56, 1, 15, 'location', 'Полтава', NULL, 'location', 56, '2022-03-15 18:47:47', NULL),
(57, 1, 15, 'add_time', 'Сегодня 19:59', NULL, 'add_time', 57, '2022-03-15 18:47:47', NULL),
(58, 1, 16, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 58, '2022-03-15 18:47:47', NULL),
(59, 1, 16, 'location', 'Степная', NULL, 'location', 59, '2022-03-15 18:47:47', NULL),
(60, 1, 16, 'add_time', 'Сегодня 19:57', NULL, 'add_time', 60, '2022-03-15 18:47:47', NULL),
(61, 1, 17, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 61, '2022-03-15 18:47:47', '2022-03-15 18:47:49'),
(62, 1, 17, 'price_info', 'Договорная', NULL, 'price_info', 62, '2022-03-15 18:47:47', '2022-03-15 18:47:49'),
(63, 1, 17, 'top', 'yes', NULL, 'top', 63, '2022-03-15 18:47:47', '2022-03-15 18:47:49'),
(64, 1, 17, 'location', 'Запорожье, Хортицкий', NULL, 'location', 64, '2022-03-15 18:47:47', '2022-03-15 18:47:49'),
(65, 1, 17, 'add_time', 'Сегодня 19:54', NULL, 'add_time', 65, '2022-03-15 18:47:47', '2022-03-15 18:47:49'),
(66, 1, 18, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 66, '2022-03-15 18:47:47', NULL),
(67, 1, 18, 'price_info', 'Договорная', NULL, 'price_info', 67, '2022-03-15 18:47:47', NULL),
(68, 1, 18, 'location', 'Черкассы', NULL, 'location', 68, '2022-03-15 18:47:47', NULL),
(69, 1, 18, 'add_time', 'Сегодня 19:53', NULL, 'add_time', 69, '2022-03-15 18:47:47', NULL),
(70, 1, 19, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 70, '2022-03-15 18:47:47', NULL),
(71, 1, 19, 'price_info', 'Договорная', NULL, 'price_info', 71, '2022-03-15 18:47:47', NULL),
(72, 1, 19, 'top', 'yes', NULL, 'top', 72, '2022-03-15 18:47:47', NULL),
(73, 1, 19, 'location', 'Белая Церковь', NULL, 'location', 73, '2022-03-15 18:47:47', NULL),
(74, 1, 19, 'add_time', 'Сегодня 19:49', NULL, 'add_time', 74, '2022-03-15 18:47:47', NULL),
(75, 1, 20, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 75, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(76, 1, 20, 'price_info', 'Договорная', NULL, 'price_info', 76, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(77, 1, 20, 'top', 'yes', NULL, 'top', 77, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(78, 1, 20, 'location', 'Драгомирчаны', NULL, 'location', 78, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(79, 1, 20, 'add_time', 'Сегодня 19:49', NULL, 'add_time', 79, '2022-03-15 18:47:47', '2022-03-15 18:47:50'),
(80, 1, 21, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 80, '2022-03-15 18:47:47', NULL),
(81, 1, 21, 'price_info', 'Договорная', NULL, 'price_info', 81, '2022-03-15 18:47:47', NULL),
(82, 1, 21, 'top', 'yes', NULL, 'top', 82, '2022-03-15 18:47:47', NULL),
(83, 1, 21, 'location', 'Каменское', NULL, 'location', 83, '2022-03-15 18:47:47', NULL),
(84, 1, 21, 'add_time', 'Сегодня 19:45', NULL, 'add_time', 84, '2022-03-15 18:47:47', NULL),
(85, 1, 22, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 85, '2022-03-15 18:47:47', NULL),
(86, 1, 22, 'location', 'Холодноводка', NULL, 'location', 86, '2022-03-15 18:47:47', NULL),
(87, 1, 22, 'add_time', 'Сегодня 19:42', NULL, 'add_time', 87, '2022-03-15 18:47:47', NULL),
(88, 1, 23, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 88, '2022-03-15 18:47:47', NULL),
(89, 1, 23, 'location', 'Львов, Франковский', NULL, 'location', 89, '2022-03-15 18:47:47', NULL),
(90, 1, 23, 'add_time', 'Сегодня 19:40', NULL, 'add_time', 90, '2022-03-15 18:47:47', NULL),
(91, 1, 24, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 91, '2022-03-15 18:47:47', NULL),
(92, 1, 24, 'price_info', 'Договорная', NULL, 'price_info', 92, '2022-03-15 18:47:47', NULL),
(93, 1, 24, 'location', 'Яготин', NULL, 'location', 93, '2022-03-15 18:47:47', NULL),
(94, 1, 24, 'add_time', 'Сегодня 19:14', NULL, 'add_time', 94, '2022-03-15 18:47:47', NULL),
(95, 1, 25, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 95, '2022-03-15 18:47:47', NULL),
(96, 1, 25, 'price_info', 'Договорная', NULL, 'price_info', 96, '2022-03-15 18:47:47', NULL),
(97, 1, 25, 'location', 'Днепр, Соборный', NULL, 'location', 97, '2022-03-15 18:47:47', NULL),
(98, 1, 25, 'add_time', 'Сегодня 19:03', NULL, 'add_time', 98, '2022-03-15 18:47:47', NULL),
(99, 1, 26, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 99, '2022-03-15 18:47:47', '2022-03-15 18:47:51'),
(100, 1, 26, 'price_info', 'Договорная', NULL, 'price_info', 100, '2022-03-15 18:47:47', '2022-03-15 18:47:51'),
(101, 1, 26, 'top', 'yes', NULL, 'top', 101, '2022-03-15 18:47:47', '2022-03-15 18:47:51'),
(102, 1, 26, 'location', 'Костополь', NULL, 'location', 102, '2022-03-15 18:47:47', '2022-03-15 18:47:51'),
(103, 1, 26, 'add_time', 'Сегодня 18:58', NULL, 'add_time', 103, '2022-03-15 18:47:47', '2022-03-15 18:47:51'),
(104, 1, 27, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 104, '2022-03-15 18:47:47', NULL),
(105, 1, 27, 'price_info', 'Договорная', NULL, 'price_info', 105, '2022-03-15 18:47:47', NULL),
(106, 1, 27, 'location', 'Софиевская Борщаговка', NULL, 'location', 106, '2022-03-15 18:47:47', NULL),
(107, 1, 27, 'add_time', 'Сегодня 18:54', NULL, 'add_time', 107, '2022-03-15 18:47:47', NULL),
(108, 1, 28, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 108, '2022-03-15 18:47:47', NULL),
(109, 1, 28, 'location', 'Торез', NULL, 'location', 109, '2022-03-15 18:47:47', NULL),
(110, 1, 28, 'add_time', 'Сегодня 18:50', NULL, 'add_time', 110, '2022-03-15 18:47:47', NULL),
(111, 1, 29, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 111, '2022-03-15 18:47:47', NULL),
(112, 1, 29, 'location', 'Каменец-Подольский', NULL, 'location', 112, '2022-03-15 18:47:47', NULL),
(113, 1, 29, 'add_time', 'Сегодня 18:49', NULL, 'add_time', 113, '2022-03-15 18:47:47', NULL),
(114, 1, 30, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 114, '2022-03-15 18:47:47', NULL),
(115, 1, 30, 'location', 'Кривой Рог, Покровский', NULL, 'location', 115, '2022-03-15 18:47:47', NULL),
(116, 1, 30, 'add_time', 'Сегодня 18:44', NULL, 'add_time', 116, '2022-03-15 18:47:47', NULL),
(117, 1, 31, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 117, '2022-03-15 18:47:47', NULL),
(118, 1, 31, 'location', 'Киверцы', NULL, 'location', 118, '2022-03-15 18:47:47', NULL),
(119, 1, 31, 'add_time', 'Сегодня 18:42', NULL, 'add_time', 119, '2022-03-15 18:47:47', NULL),
(120, 1, 32, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 120, '2022-03-15 18:47:47', NULL),
(121, 1, 32, 'location', 'Одесса, Малиновский', NULL, 'location', 121, '2022-03-15 18:47:47', NULL),
(122, 1, 32, 'add_time', 'Сегодня 18:40', NULL, 'add_time', 122, '2022-03-15 18:47:47', NULL),
(123, 1, 33, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 123, '2022-03-15 18:47:47', NULL),
(124, 1, 33, 'price_info', 'Договорная', NULL, 'price_info', 124, '2022-03-15 18:47:47', NULL),
(125, 1, 33, 'location', 'Днепр, Индустриальный', NULL, 'location', 125, '2022-03-15 18:47:47', NULL),
(126, 1, 33, 'add_time', 'Сегодня 18:31', NULL, 'add_time', 126, '2022-03-15 18:47:47', NULL),
(127, 1, 34, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 127, '2022-03-15 18:47:47', NULL),
(128, 1, 34, 'price_info', 'Договорная', NULL, 'price_info', 128, '2022-03-15 18:47:47', NULL),
(129, 1, 34, 'top', 'yes', NULL, 'top', 129, '2022-03-15 18:47:47', NULL),
(130, 1, 34, 'location', 'Монастырище', NULL, 'location', 130, '2022-03-15 18:47:47', NULL),
(131, 1, 34, 'add_time', 'Сегодня 18:26', NULL, 'add_time', 131, '2022-03-15 18:47:47', NULL),
(132, 1, 35, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 132, '2022-03-15 18:47:47', NULL),
(133, 1, 35, 'location', 'Тараща', NULL, 'location', 133, '2022-03-15 18:47:47', NULL),
(134, 1, 35, 'add_time', 'Сегодня 18:24', NULL, 'add_time', 134, '2022-03-15 18:47:47', NULL),
(135, 1, 36, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 135, '2022-03-15 18:47:47', NULL),
(136, 1, 36, 'location', 'Сопов', NULL, 'location', 136, '2022-03-15 18:47:47', NULL),
(137, 1, 36, 'add_time', 'Сегодня 18:23', NULL, 'add_time', 137, '2022-03-15 18:47:47', NULL),
(138, 1, 37, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 138, '2022-03-15 18:47:48', NULL),
(139, 1, 37, 'location', 'Новомосковск', NULL, 'location', 139, '2022-03-15 18:47:48', NULL),
(140, 1, 37, 'add_time', 'Сегодня 18:20', NULL, 'add_time', 140, '2022-03-15 18:47:48', NULL),
(141, 1, 38, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 141, '2022-03-15 18:47:48', NULL),
(142, 1, 38, 'location', 'Донецк, Кировский', NULL, 'location', 142, '2022-03-15 18:47:48', NULL),
(143, 1, 38, 'add_time', 'Сегодня 18:15', NULL, 'add_time', 143, '2022-03-15 18:47:48', NULL),
(144, 1, 39, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 144, '2022-03-15 18:47:48', NULL),
(145, 1, 39, 'location', 'Кривой Рог, Покровский', NULL, 'location', 145, '2022-03-15 18:47:48', NULL),
(146, 1, 39, 'add_time', 'Сегодня 17:20', NULL, 'add_time', 146, '2022-03-15 18:47:48', NULL),
(147, 1, 40, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 147, '2022-03-15 18:47:48', NULL),
(148, 1, 40, 'top', 'yes', NULL, 'top', 148, '2022-03-15 18:47:48', NULL),
(149, 1, 40, 'location', 'Покровск', NULL, 'location', 149, '2022-03-15 18:47:48', NULL),
(150, 1, 40, 'add_time', 'Сегодня 17:11', NULL, 'add_time', 150, '2022-03-15 18:47:48', NULL),
(151, 1, 41, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 151, '2022-03-15 18:47:48', NULL),
(152, 1, 41, 'price_info', 'Договорная', NULL, 'price_info', 152, '2022-03-15 18:47:48', NULL),
(153, 1, 41, 'location', 'Энергодар', NULL, 'location', 153, '2022-03-15 18:47:48', NULL),
(154, 1, 41, 'add_time', 'Сегодня 17:11', NULL, 'add_time', 154, '2022-03-15 18:47:48', NULL),
(155, 1, 42, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 155, '2022-03-15 18:47:48', NULL),
(156, 1, 42, 'price_info', 'Договорная', NULL, 'price_info', 156, '2022-03-15 18:47:48', NULL),
(157, 1, 42, 'location', 'Тернополь', NULL, 'location', 157, '2022-03-15 18:47:48', NULL),
(158, 1, 42, 'add_time', 'Сегодня 17:05', NULL, 'add_time', 158, '2022-03-15 18:47:48', NULL),
(159, 1, 43, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 159, '2022-03-15 18:47:48', NULL),
(160, 1, 43, 'price_info', 'Договорная', NULL, 'price_info', 160, '2022-03-15 18:47:48', NULL),
(161, 1, 43, 'location', 'Днепр, Соборный', NULL, 'location', 161, '2022-03-15 18:47:48', NULL),
(162, 1, 43, 'add_time', 'Сегодня 16:56', NULL, 'add_time', 162, '2022-03-15 18:47:48', NULL),
(163, 1, 44, 'breadcrumbs', 'Авто/Продажа авто - авто', NULL, 'breadcrumbs', 163, '2022-03-15 18:47:48', NULL),
(164, 1, 44, 'top', 'yes', NULL, 'top', 164, '2022-03-15 18:47:48', NULL),
(165, 1, 44, 'location', 'Вараш', NULL, 'location', 165, '2022-03-15 18:47:48', NULL),
(166, 1, 44, 'add_time', 'Сегодня 16:56', NULL, 'add_time', 166, '2022-03-15 18:47:48', NULL),
(167, 1, 45, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 167, '2022-03-15 18:47:48', NULL),
(168, 1, 45, 'top', 'yes', NULL, 'top', 168, '2022-03-15 18:47:48', NULL),
(169, 1, 45, 'location', 'Волноваха', NULL, 'location', 169, '2022-03-15 18:47:48', NULL),
(170, 1, 45, 'add_time', 'Вчера 18:05', NULL, 'add_time', 170, '2022-03-15 18:47:48', NULL),
(171, 1, 46, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 171, '2022-03-15 18:47:48', NULL),
(172, 1, 46, 'price_info', 'Договорная', NULL, 'price_info', 172, '2022-03-15 18:47:48', NULL),
(173, 1, 46, 'top', 'yes', NULL, 'top', 173, '2022-03-15 18:47:48', NULL),
(174, 1, 46, 'location', 'Загородье', NULL, 'location', 174, '2022-03-15 18:47:48', NULL),
(175, 1, 46, 'add_time', '12  март', NULL, 'add_time', 175, '2022-03-15 18:47:48', NULL),
(176, 1, 47, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 176, '2022-03-15 18:47:48', NULL),
(177, 1, 47, 'top', 'yes', NULL, 'top', 177, '2022-03-15 18:47:48', NULL),
(178, 1, 47, 'location', 'Ровно', NULL, 'location', 178, '2022-03-15 18:47:48', NULL),
(179, 1, 47, 'add_time', '25  февр.', NULL, 'add_time', 179, '2022-03-15 18:47:48', NULL),
(180, 1, 48, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 180, '2022-03-15 18:47:48', NULL),
(181, 1, 48, 'price_info', 'Договорная', NULL, 'price_info', 181, '2022-03-15 18:47:48', NULL),
(182, 1, 48, 'top', 'yes', NULL, 'top', 182, '2022-03-15 18:47:48', NULL),
(183, 1, 48, 'location', 'Килия', NULL, 'location', 183, '2022-03-15 18:47:48', NULL),
(184, 1, 48, 'add_time', '26  февр.', NULL, 'add_time', 184, '2022-03-15 18:47:48', NULL),
(185, 1, 49, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 185, '2022-03-15 18:47:48', NULL),
(186, 1, 49, 'price_info', 'Договорная', NULL, 'price_info', 186, '2022-03-15 18:47:48', NULL),
(187, 1, 49, 'top', 'yes', NULL, 'top', 187, '2022-03-15 18:47:48', NULL),
(188, 1, 49, 'location', 'Ирпень', NULL, 'location', 188, '2022-03-15 18:47:48', NULL),
(189, 1, 49, 'add_time', '13  март', NULL, 'add_time', 189, '2022-03-15 18:47:48', NULL),
(190, 1, 50, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 190, '2022-03-15 18:47:48', NULL),
(191, 1, 50, 'location', 'Днепр, Центральный', NULL, 'location', 191, '2022-03-15 18:47:48', NULL),
(192, 1, 50, 'add_time', 'Сегодня 16:45', NULL, 'add_time', 192, '2022-03-15 18:47:48', NULL),
(193, 1, 51, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 193, '2022-03-15 18:47:48', NULL),
(194, 1, 51, 'location', 'Мелитополь', NULL, 'location', 194, '2022-03-15 18:47:48', NULL),
(195, 1, 51, 'add_time', 'Сегодня 16:36', NULL, 'add_time', 195, '2022-03-15 18:47:48', NULL),
(196, 1, 52, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 196, '2022-03-15 18:47:48', NULL),
(197, 1, 52, 'location', 'Николаев, Заводский', NULL, 'location', 197, '2022-03-15 18:47:48', NULL),
(198, 1, 52, 'add_time', 'Сегодня 16:33', NULL, 'add_time', 198, '2022-03-15 18:47:48', NULL),
(199, 1, 53, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 199, '2022-03-15 18:47:48', NULL),
(200, 1, 53, 'location', 'Вороняки', NULL, 'location', 200, '2022-03-15 18:47:48', NULL),
(201, 1, 53, 'add_time', 'Сегодня 16:19', NULL, 'add_time', 201, '2022-03-15 18:47:48', NULL),
(202, 1, 54, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 202, '2022-03-15 18:47:48', NULL),
(203, 1, 54, 'price_info', 'Договорная', NULL, 'price_info', 203, '2022-03-15 18:47:48', NULL),
(204, 1, 54, 'top', 'yes', NULL, 'top', 204, '2022-03-15 18:47:48', NULL),
(205, 1, 54, 'location', 'Дунаевцы', NULL, 'location', 205, '2022-03-15 18:47:48', NULL),
(206, 1, 54, 'add_time', 'Сегодня 16:17', NULL, 'add_time', 206, '2022-03-15 18:47:48', NULL),
(207, 1, 55, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 207, '2022-03-15 18:47:48', NULL),
(208, 1, 55, 'price_info', 'Договорная', NULL, 'price_info', 208, '2022-03-15 18:47:48', NULL),
(209, 1, 55, 'location', 'Новый Стародуб', NULL, 'location', 209, '2022-03-15 18:47:48', NULL),
(210, 1, 55, 'add_time', 'Сегодня 16:14', NULL, 'add_time', 210, '2022-03-15 18:47:48', NULL),
(211, 1, 56, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 211, '2022-03-15 18:47:48', NULL),
(212, 1, 56, 'location', 'Павлоград', NULL, 'location', 212, '2022-03-15 18:47:48', NULL),
(213, 1, 56, 'add_time', 'Сегодня 16:06', NULL, 'add_time', 213, '2022-03-15 18:47:48', NULL),
(214, 1, 57, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 214, '2022-03-15 18:47:48', NULL),
(215, 1, 57, 'price_info', 'Договорная', NULL, 'price_info', 215, '2022-03-15 18:47:48', NULL),
(216, 1, 57, 'location', 'Житомир, Богунский', NULL, 'location', 216, '2022-03-15 18:47:48', NULL),
(217, 1, 57, 'add_time', 'Сегодня 16:03', NULL, 'add_time', 217, '2022-03-15 18:47:48', NULL),
(218, 1, 58, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 218, '2022-03-15 18:47:48', NULL),
(219, 1, 58, 'location', 'Одесса, Малиновский', NULL, 'location', 219, '2022-03-15 18:47:48', NULL),
(220, 1, 58, 'add_time', 'Сегодня 15:58', NULL, 'add_time', 220, '2022-03-15 18:47:48', NULL),
(221, 1, 59, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 221, '2022-03-15 18:47:48', NULL),
(222, 1, 59, 'location', 'Одесса, Малиновский', NULL, 'location', 222, '2022-03-15 18:47:48', NULL),
(223, 1, 59, 'add_time', 'Сегодня 15:58', NULL, 'add_time', 223, '2022-03-15 18:47:48', NULL),
(224, 1, 60, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 224, '2022-03-15 18:47:48', NULL),
(225, 1, 60, 'location', 'Одесса, Малиновский', NULL, 'location', 225, '2022-03-15 18:47:48', NULL),
(226, 1, 60, 'add_time', 'Сегодня 15:58', NULL, 'add_time', 226, '2022-03-15 18:47:48', NULL),
(227, 1, 61, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 227, '2022-03-15 18:47:48', NULL),
(228, 1, 61, 'location', 'Одесса, Малиновский', NULL, 'location', 228, '2022-03-15 18:47:48', NULL),
(229, 1, 61, 'add_time', 'Сегодня 15:58', NULL, 'add_time', 229, '2022-03-15 18:47:48', NULL),
(230, 1, 62, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 230, '2022-03-15 18:47:48', NULL),
(231, 1, 62, 'location', 'Одесса, Малиновский', NULL, 'location', 231, '2022-03-15 18:47:48', NULL),
(232, 1, 62, 'add_time', 'Сегодня 15:58', NULL, 'add_time', 232, '2022-03-15 18:47:48', NULL),
(233, 1, 63, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 233, '2022-03-15 18:47:48', NULL),
(234, 1, 63, 'location', 'Одесса, Малиновский', NULL, 'location', 234, '2022-03-15 18:47:48', NULL),
(235, 1, 63, 'add_time', 'Сегодня 15:58', NULL, 'add_time', 235, '2022-03-15 18:47:48', NULL),
(236, 1, 64, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 236, '2022-03-15 18:47:48', NULL),
(237, 1, 64, 'location', 'Черновцы', NULL, 'location', 237, '2022-03-15 18:47:48', NULL),
(238, 1, 64, 'add_time', 'Сегодня 15:50', NULL, 'add_time', 238, '2022-03-15 18:47:48', NULL),
(239, 1, 65, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 239, '2022-03-15 18:47:48', NULL),
(240, 1, 65, 'price_info', 'Договорная', NULL, 'price_info', 240, '2022-03-15 18:47:48', NULL),
(241, 1, 65, 'location', 'Хмельницкий', NULL, 'location', 241, '2022-03-15 18:47:48', NULL),
(242, 1, 65, 'add_time', 'Сегодня 15:48', NULL, 'add_time', 242, '2022-03-15 18:47:48', NULL),
(243, 1, 66, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 243, '2022-03-15 18:47:48', NULL),
(244, 1, 66, 'location', 'Виноградов', NULL, 'location', 244, '2022-03-15 18:47:48', NULL),
(245, 1, 66, 'add_time', 'Сегодня 15:45', NULL, 'add_time', 245, '2022-03-15 18:47:48', NULL),
(246, 1, 67, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 246, '2022-03-15 18:47:48', NULL),
(247, 1, 67, 'top', 'yes', NULL, 'top', 247, '2022-03-15 18:47:48', NULL),
(248, 1, 67, 'location', 'Рудня', NULL, 'location', 248, '2022-03-15 18:47:48', NULL),
(249, 1, 67, 'add_time', 'Сегодня 15:44', NULL, 'add_time', 249, '2022-03-15 18:47:48', NULL),
(250, 1, 68, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 250, '2022-03-15 18:47:48', NULL),
(251, 1, 68, 'top', 'yes', NULL, 'top', 251, '2022-03-15 18:47:48', NULL),
(252, 1, 68, 'location', 'Нетешин', NULL, 'location', 252, '2022-03-15 18:47:48', NULL),
(253, 1, 68, 'add_time', 'Сегодня 15:20', NULL, 'add_time', 253, '2022-03-15 18:47:48', NULL),
(254, 1, 69, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 254, '2022-03-15 18:47:49', NULL),
(255, 1, 69, 'location', 'Киев, Оболонский', NULL, 'location', 255, '2022-03-15 18:47:49', NULL),
(256, 1, 69, 'add_time', 'Сегодня 15:16', NULL, 'add_time', 256, '2022-03-15 18:47:49', NULL),
(257, 1, 70, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 257, '2022-03-15 18:47:49', NULL),
(258, 1, 70, 'price_info', 'Договорная', NULL, 'price_info', 258, '2022-03-15 18:47:49', NULL),
(259, 1, 70, 'location', 'Коломыя', NULL, 'location', 259, '2022-03-15 18:47:49', NULL),
(260, 1, 70, 'add_time', 'Сегодня 15:13', NULL, 'add_time', 260, '2022-03-15 18:47:49', NULL),
(261, 1, 71, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 261, '2022-03-15 18:47:49', NULL),
(262, 1, 71, 'price_info', 'Договорная', NULL, 'price_info', 262, '2022-03-15 18:47:49', NULL),
(263, 1, 71, 'top', 'yes', NULL, 'top', 263, '2022-03-15 18:47:49', NULL),
(264, 1, 71, 'location', 'Стрый', NULL, 'location', 264, '2022-03-15 18:47:49', NULL),
(265, 1, 71, 'add_time', 'Сегодня 15:12', NULL, 'add_time', 265, '2022-03-15 18:47:49', NULL),
(266, 1, 72, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 266, '2022-03-15 18:47:49', NULL),
(267, 1, 72, 'location', 'Житомир, Путятинка', NULL, 'location', 267, '2022-03-15 18:47:49', NULL),
(268, 1, 72, 'add_time', 'Сегодня 15:12', NULL, 'add_time', 268, '2022-03-15 18:47:49', NULL),
(269, 1, 73, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 269, '2022-03-15 18:47:49', NULL),
(270, 1, 73, 'location', 'Мамрин', NULL, 'location', 270, '2022-03-15 18:47:49', NULL),
(271, 1, 73, 'add_time', 'Сегодня 14:59', NULL, 'add_time', 271, '2022-03-15 18:47:49', NULL),
(272, 1, 74, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 272, '2022-03-15 18:47:49', NULL),
(273, 1, 74, 'location', 'Львов, Сиховский', NULL, 'location', 273, '2022-03-15 18:47:49', NULL),
(274, 1, 74, 'add_time', 'Сегодня 14:52', NULL, 'add_time', 274, '2022-03-15 18:47:49', NULL),
(275, 1, 75, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 275, '2022-03-15 18:47:49', NULL),
(276, 1, 75, 'location', 'Жмеринка', NULL, 'location', 276, '2022-03-15 18:47:49', NULL),
(277, 1, 75, 'add_time', 'Сегодня 14:43', NULL, 'add_time', 277, '2022-03-15 18:47:49', NULL),
(278, 1, 76, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 278, '2022-03-15 18:47:49', NULL),
(279, 1, 76, 'price_info', 'Договорная', NULL, 'price_info', 279, '2022-03-15 18:47:49', NULL),
(280, 1, 76, 'location', 'Киев, Голосеевский', NULL, 'location', 280, '2022-03-15 18:47:49', NULL),
(281, 1, 76, 'add_time', 'Сегодня 14:40', NULL, 'add_time', 281, '2022-03-15 18:47:49', NULL),
(282, 1, 77, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 282, '2022-03-15 18:47:49', NULL),
(283, 1, 77, 'price_info', 'Договорная', NULL, 'price_info', 283, '2022-03-15 18:47:49', NULL),
(284, 1, 77, 'location', 'Львов, Франковский', NULL, 'location', 284, '2022-03-15 18:47:49', NULL),
(285, 1, 77, 'add_time', 'Сегодня 14:39', NULL, 'add_time', 285, '2022-03-15 18:47:49', NULL),
(286, 1, 78, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 286, '2022-03-15 18:47:49', NULL),
(287, 1, 78, 'location', 'Краснодон', NULL, 'location', 287, '2022-03-15 18:47:49', NULL),
(288, 1, 78, 'add_time', 'Сегодня 14:39', NULL, 'add_time', 288, '2022-03-15 18:47:49', NULL),
(289, 1, 79, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 289, '2022-03-15 18:47:49', NULL),
(290, 1, 79, 'price_info', 'Договорная', NULL, 'price_info', 290, '2022-03-15 18:47:49', NULL),
(291, 1, 79, 'location', 'Кривой Рог, Саксаганский', NULL, 'location', 291, '2022-03-15 18:47:49', NULL),
(292, 1, 79, 'add_time', 'Сегодня 14:34', NULL, 'add_time', 292, '2022-03-15 18:47:49', NULL),
(293, 1, 80, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 293, '2022-03-15 18:47:49', NULL),
(294, 1, 80, 'price_info', 'Договорная', NULL, 'price_info', 294, '2022-03-15 18:47:49', NULL),
(295, 1, 80, 'location', 'Черновцы', NULL, 'location', 295, '2022-03-15 18:47:49', NULL),
(296, 1, 80, 'add_time', 'Сегодня 14:29', NULL, 'add_time', 296, '2022-03-15 18:47:49', NULL),
(297, 1, 81, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 297, '2022-03-15 18:47:49', NULL),
(298, 1, 81, 'location', 'Днепр, Амур-Нижнеднепровский', NULL, 'location', 298, '2022-03-15 18:47:49', NULL),
(299, 1, 81, 'add_time', 'Сегодня 14:23', NULL, 'add_time', 299, '2022-03-15 18:47:49', NULL),
(300, 1, 82, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 300, '2022-03-15 18:47:49', NULL),
(301, 1, 82, 'price_info', 'Договорная', NULL, 'price_info', 301, '2022-03-15 18:47:49', NULL),
(302, 1, 82, 'location', 'Ворохта', NULL, 'location', 302, '2022-03-15 18:47:49', NULL),
(303, 1, 82, 'add_time', 'Сегодня 14:14', NULL, 'add_time', 303, '2022-03-15 18:47:49', NULL),
(304, 1, 83, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 304, '2022-03-15 18:47:49', NULL),
(305, 1, 83, 'price_info', 'Договорная', NULL, 'price_info', 305, '2022-03-15 18:47:49', NULL),
(306, 1, 83, 'top', 'yes', NULL, 'top', 306, '2022-03-15 18:47:49', NULL),
(307, 1, 83, 'location', 'Вижница', NULL, 'location', 307, '2022-03-15 18:47:49', NULL),
(308, 1, 83, 'add_time', 'Сегодня 14:12', NULL, 'add_time', 308, '2022-03-15 18:47:49', NULL),
(309, 1, 84, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 309, '2022-03-15 18:47:49', NULL),
(310, 1, 84, 'price_info', 'Договорная', NULL, 'price_info', 310, '2022-03-15 18:47:49', NULL),
(311, 1, 84, 'top', 'yes', NULL, 'top', 311, '2022-03-15 18:47:49', NULL),
(312, 1, 84, 'location', 'Побужское', NULL, 'location', 312, '2022-03-15 18:47:49', NULL),
(313, 1, 84, 'add_time', 'Сегодня 14:06', NULL, 'add_time', 313, '2022-03-15 18:47:49', NULL),
(314, 1, 85, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 314, '2022-03-15 18:47:49', NULL),
(315, 1, 85, 'location', 'Киев, Оболонский', NULL, 'location', 315, '2022-03-15 18:47:49', NULL),
(316, 1, 85, 'add_time', 'Сегодня 14:05', NULL, 'add_time', 316, '2022-03-15 18:47:49', NULL),
(317, 1, 86, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 317, '2022-03-15 18:47:49', NULL),
(318, 1, 86, 'location', 'Львов, Галицкий', NULL, 'location', 318, '2022-03-15 18:47:49', NULL),
(319, 1, 86, 'add_time', 'Сегодня 14:05', NULL, 'add_time', 319, '2022-03-15 18:47:49', NULL),
(320, 1, 87, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 320, '2022-03-15 18:47:49', NULL),
(321, 1, 87, 'location', 'Гадяч', NULL, 'location', 321, '2022-03-15 18:47:49', NULL),
(322, 1, 87, 'add_time', 'Сегодня 14:01', NULL, 'add_time', 322, '2022-03-15 18:47:49', NULL),
(323, 1, 88, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 2 - авто', NULL, 'breadcrumbs', 323, '2022-03-15 18:47:49', NULL),
(324, 1, 88, 'price_info', 'Договорная', NULL, 'price_info', 324, '2022-03-15 18:47:49', NULL),
(325, 1, 88, 'location', 'Краматорск', NULL, 'location', 325, '2022-03-15 18:47:49', NULL),
(326, 1, 88, 'add_time', 'Сегодня 13:53', NULL, 'add_time', 326, '2022-03-15 18:47:49', NULL),
(327, 1, 89, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 327, '2022-03-15 18:47:49', NULL),
(328, 1, 89, 'top', 'yes', NULL, 'top', 328, '2022-03-15 18:47:49', NULL),
(329, 1, 89, 'location', 'Николаевка', NULL, 'location', 329, '2022-03-15 18:47:49', NULL),
(330, 1, 89, 'add_time', 'Вчера 14:14', NULL, 'add_time', 330, '2022-03-15 18:47:49', NULL),
(331, 1, 90, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 331, '2022-03-15 18:47:49', NULL),
(332, 1, 90, 'price_info', 'Договорная', NULL, 'price_info', 332, '2022-03-15 18:47:49', NULL),
(333, 1, 90, 'top', 'yes', NULL, 'top', 333, '2022-03-15 18:47:49', NULL),
(334, 1, 90, 'location', 'Яворов', NULL, 'location', 334, '2022-03-15 18:47:49', NULL),
(335, 1, 90, 'add_time', 'Вчера 20:14', NULL, 'add_time', 335, '2022-03-15 18:47:49', NULL),
(336, 1, 91, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 336, '2022-03-15 18:47:49', '2022-03-15 18:47:51'),
(337, 1, 91, 'price_info', 'Договорная', NULL, 'price_info', 337, '2022-03-15 18:47:49', '2022-03-15 18:47:51'),
(338, 1, 91, 'top', 'yes', NULL, 'top', 338, '2022-03-15 18:47:49', '2022-03-15 18:47:51'),
(339, 1, 91, 'location', 'Липовец', NULL, 'location', 339, '2022-03-15 18:47:49', '2022-03-15 18:47:51'),
(340, 1, 91, 'add_time', 'Сегодня 09:52', NULL, 'add_time', 340, '2022-03-15 18:47:49', '2022-03-15 18:47:51'),
(341, 1, 92, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 341, '2022-03-15 18:47:49', NULL),
(342, 1, 92, 'price_info', 'Договорная', NULL, 'price_info', 342, '2022-03-15 18:47:49', NULL),
(343, 1, 92, 'top', 'yes', NULL, 'top', 343, '2022-03-15 18:47:49', NULL),
(344, 1, 92, 'location', 'Беленькое', NULL, 'location', 344, '2022-03-15 18:47:49', NULL),
(345, 1, 92, 'add_time', '21  февр.', NULL, 'add_time', 345, '2022-03-15 18:47:49', NULL),
(346, 1, 93, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 346, '2022-03-15 18:47:49', NULL),
(347, 1, 93, 'location', 'Днепр, Индустриальный', NULL, 'location', 347, '2022-03-15 18:47:49', NULL),
(348, 1, 93, 'add_time', 'Сегодня 13:45', NULL, 'add_time', 348, '2022-03-15 18:47:49', NULL),
(349, 1, 94, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 349, '2022-03-15 18:47:49', NULL),
(350, 1, 94, 'location', 'Киев, Подольский', NULL, 'location', 350, '2022-03-15 18:47:49', NULL),
(351, 1, 94, 'add_time', 'Сегодня 13:44', NULL, 'add_time', 351, '2022-03-15 18:47:49', NULL),
(352, 1, 95, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 352, '2022-03-15 18:47:49', NULL),
(353, 1, 95, 'location', 'Кривой Рог, Покровский', NULL, 'location', 353, '2022-03-15 18:47:49', NULL),
(354, 1, 95, 'add_time', 'Сегодня 13:40', NULL, 'add_time', 354, '2022-03-15 18:47:49', NULL),
(355, 1, 96, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 355, '2022-03-15 18:47:49', NULL),
(356, 1, 96, 'location', 'Киев, Подольский', NULL, 'location', 356, '2022-03-15 18:47:49', NULL),
(357, 1, 96, 'add_time', 'Сегодня 13:40', NULL, 'add_time', 357, '2022-03-15 18:47:49', NULL),
(358, 1, 97, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 358, '2022-03-15 18:47:49', NULL),
(359, 1, 97, 'top', 'yes', NULL, 'top', 359, '2022-03-15 18:47:49', NULL),
(360, 1, 97, 'location', 'Полтава', NULL, 'location', 360, '2022-03-15 18:47:49', NULL),
(361, 1, 97, 'add_time', 'Сегодня 13:39', NULL, 'add_time', 361, '2022-03-15 18:47:49', NULL),
(362, 1, 98, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 362, '2022-03-15 18:47:49', NULL),
(363, 1, 98, 'price_info', 'Договорная', NULL, 'price_info', 363, '2022-03-15 18:47:49', NULL),
(364, 1, 98, 'location', 'Вараш', NULL, 'location', 364, '2022-03-15 18:47:49', NULL),
(365, 1, 98, 'add_time', 'Сегодня 13:16', NULL, 'add_time', 365, '2022-03-15 18:47:49', NULL),
(366, 1, 99, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 366, '2022-03-15 18:47:49', NULL),
(367, 1, 99, 'location', 'Киев, Подольский', NULL, 'location', 367, '2022-03-15 18:47:49', NULL),
(368, 1, 99, 'add_time', 'Сегодня 13:15', NULL, 'add_time', 368, '2022-03-15 18:47:49', NULL),
(369, 1, 100, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 369, '2022-03-15 18:47:49', NULL),
(370, 1, 100, 'location', 'Киев, Подольский', NULL, 'location', 370, '2022-03-15 18:47:49', NULL),
(371, 1, 100, 'add_time', 'Сегодня 13:10', NULL, 'add_time', 371, '2022-03-15 18:47:49', NULL),
(372, 1, 101, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 372, '2022-03-15 18:47:49', NULL),
(373, 1, 101, 'location', 'Токмак', NULL, 'location', 373, '2022-03-15 18:47:49', NULL),
(374, 1, 101, 'add_time', 'Сегодня 13:02', NULL, 'add_time', 374, '2022-03-15 18:47:49', NULL),
(375, 1, 102, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 375, '2022-03-15 18:47:50', NULL),
(376, 1, 102, 'location', 'Николаев Жовтневый', NULL, 'location', 376, '2022-03-15 18:47:50', NULL),
(377, 1, 102, 'add_time', 'Сегодня 12:54', NULL, 'add_time', 377, '2022-03-15 18:47:50', NULL),
(378, 1, 103, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 378, '2022-03-15 18:47:50', NULL),
(379, 1, 103, 'price_info', 'Договорная', NULL, 'price_info', 379, '2022-03-15 18:47:50', NULL),
(380, 1, 103, 'location', 'Здолбунов', NULL, 'location', 380, '2022-03-15 18:47:50', NULL),
(381, 1, 103, 'add_time', 'Сегодня 12:50', NULL, 'add_time', 381, '2022-03-15 18:47:50', NULL),
(382, 1, 104, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 382, '2022-03-15 18:47:50', NULL),
(383, 1, 104, 'price_info', 'Договорная', NULL, 'price_info', 383, '2022-03-15 18:47:50', NULL),
(384, 1, 104, 'location', 'Винница, Замостянский', NULL, 'location', 384, '2022-03-15 18:47:50', NULL),
(385, 1, 104, 'add_time', 'Сегодня 12:48', NULL, 'add_time', 385, '2022-03-15 18:47:50', NULL),
(386, 1, 105, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 386, '2022-03-15 18:47:50', NULL),
(387, 1, 105, 'location', 'Киев, Подольский', NULL, 'location', 387, '2022-03-15 18:47:50', NULL),
(388, 1, 105, 'add_time', 'Сегодня 12:46', NULL, 'add_time', 388, '2022-03-15 18:47:50', NULL),
(389, 1, 106, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 389, '2022-03-15 18:47:50', NULL),
(390, 1, 106, 'price_info', 'Договорная', NULL, 'price_info', 390, '2022-03-15 18:47:50', NULL),
(391, 1, 106, 'location', 'Киев, Шевченковский', NULL, 'location', 391, '2022-03-15 18:47:50', NULL),
(392, 1, 106, 'add_time', 'Сегодня 12:46', NULL, 'add_time', 392, '2022-03-15 18:47:50', NULL),
(393, 1, 107, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 393, '2022-03-15 18:47:50', NULL),
(394, 1, 107, 'location', 'Киев, Подольский', NULL, 'location', 394, '2022-03-15 18:47:50', NULL),
(395, 1, 107, 'add_time', 'Сегодня 12:44', NULL, 'add_time', 395, '2022-03-15 18:47:50', NULL),
(396, 1, 108, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 396, '2022-03-15 18:47:50', NULL),
(397, 1, 108, 'location', 'Киев, Оболонский', NULL, 'location', 397, '2022-03-15 18:47:50', NULL),
(398, 1, 108, 'add_time', 'Сегодня 12:39', NULL, 'add_time', 398, '2022-03-15 18:47:50', NULL),
(399, 1, 109, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 399, '2022-03-15 18:47:50', NULL),
(400, 1, 109, 'price_info', 'Договорная', NULL, 'price_info', 400, '2022-03-15 18:47:50', NULL),
(401, 1, 109, 'location', 'Ивано-Франковск', NULL, 'location', 401, '2022-03-15 18:47:50', NULL),
(402, 1, 109, 'add_time', 'Сегодня 12:34', NULL, 'add_time', 402, '2022-03-15 18:47:50', NULL),
(403, 1, 110, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 403, '2022-03-15 18:47:50', NULL),
(404, 1, 110, 'location', 'Киев, Подольский', NULL, 'location', 404, '2022-03-15 18:47:50', NULL),
(405, 1, 110, 'add_time', 'Сегодня 12:27', NULL, 'add_time', 405, '2022-03-15 18:47:50', NULL),
(406, 1, 111, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 406, '2022-03-15 18:47:50', NULL),
(407, 1, 111, 'price_info', 'Договорная', NULL, 'price_info', 407, '2022-03-15 18:47:50', NULL),
(408, 1, 111, 'location', 'Петренко', NULL, 'location', 408, '2022-03-15 18:47:50', NULL),
(409, 1, 111, 'add_time', 'Сегодня 12:25', NULL, 'add_time', 409, '2022-03-15 18:47:50', NULL),
(410, 1, 112, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 410, '2022-03-15 18:47:50', NULL),
(411, 1, 112, 'location', 'Киев, Подольский', NULL, 'location', 411, '2022-03-15 18:47:50', NULL),
(412, 1, 112, 'add_time', 'Сегодня 12:24', NULL, 'add_time', 412, '2022-03-15 18:47:50', NULL),
(413, 1, 113, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 413, '2022-03-15 18:47:50', NULL),
(414, 1, 113, 'location', 'Киев, Подольский', NULL, 'location', 414, '2022-03-15 18:47:50', NULL),
(415, 1, 113, 'add_time', 'Сегодня 12:21', NULL, 'add_time', 415, '2022-03-15 18:47:50', NULL),
(416, 1, 114, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 416, '2022-03-15 18:47:50', NULL),
(417, 1, 114, 'location', 'Киев, Подольский', NULL, 'location', 417, '2022-03-15 18:47:50', NULL),
(418, 1, 114, 'add_time', 'Сегодня 12:20', NULL, 'add_time', 418, '2022-03-15 18:47:50', NULL),
(419, 1, 115, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 419, '2022-03-15 18:47:50', NULL),
(420, 1, 115, 'price_info', 'Договорная', NULL, 'price_info', 420, '2022-03-15 18:47:50', NULL),
(421, 1, 115, 'location', 'Ковель', NULL, 'location', 421, '2022-03-15 18:47:50', NULL),
(422, 1, 115, 'add_time', 'Сегодня 12:19', NULL, 'add_time', 422, '2022-03-15 18:47:50', NULL),
(423, 1, 116, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 423, '2022-03-15 18:47:50', NULL),
(424, 1, 116, 'location', 'Каменское', NULL, 'location', 424, '2022-03-15 18:47:50', NULL),
(425, 1, 116, 'add_time', 'Сегодня 12:17', NULL, 'add_time', 425, '2022-03-15 18:47:50', NULL),
(426, 1, 117, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 426, '2022-03-15 18:47:50', NULL),
(427, 1, 117, 'location', 'Киев, Подольский', NULL, 'location', 427, '2022-03-15 18:47:50', NULL),
(428, 1, 117, 'add_time', 'Сегодня 12:14', NULL, 'add_time', 428, '2022-03-15 18:47:50', NULL),
(429, 1, 118, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 429, '2022-03-15 18:47:50', NULL),
(430, 1, 118, 'location', 'Киев, Подольский', NULL, 'location', 430, '2022-03-15 18:47:50', NULL),
(431, 1, 118, 'add_time', 'Сегодня 12:11', NULL, 'add_time', 431, '2022-03-15 18:47:50', NULL),
(432, 1, 119, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 432, '2022-03-15 18:47:50', NULL),
(433, 1, 119, 'location', 'Кременчуг', NULL, 'location', 433, '2022-03-15 18:47:50', NULL),
(434, 1, 119, 'add_time', 'Сегодня 12:05', NULL, 'add_time', 434, '2022-03-15 18:47:50', NULL),
(435, 1, 120, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 435, '2022-03-15 18:47:50', NULL),
(436, 1, 120, 'price_info', 'Договорная', NULL, 'price_info', 436, '2022-03-15 18:47:50', NULL),
(437, 1, 120, 'location', 'Путила', NULL, 'location', 437, '2022-03-15 18:47:50', NULL),
(438, 1, 120, 'add_time', 'Сегодня 12:03', NULL, 'add_time', 438, '2022-03-15 18:47:50', NULL),
(439, 1, 121, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 439, '2022-03-15 18:47:50', NULL),
(440, 1, 121, 'price_info', 'Договорная', NULL, 'price_info', 440, '2022-03-15 18:47:50', NULL),
(441, 1, 121, 'location', 'Киверцы', NULL, 'location', 441, '2022-03-15 18:47:50', NULL),
(442, 1, 121, 'add_time', 'Сегодня 11:58', NULL, 'add_time', 442, '2022-03-15 18:47:50', NULL),
(443, 1, 122, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 443, '2022-03-15 18:47:50', NULL),
(444, 1, 122, 'location', 'Киев, Подольский', NULL, 'location', 444, '2022-03-15 18:47:50', NULL),
(445, 1, 122, 'add_time', 'Сегодня 11:48', NULL, 'add_time', 445, '2022-03-15 18:47:50', NULL),
(446, 1, 123, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 446, '2022-03-15 18:47:50', NULL),
(447, 1, 123, 'price_info', 'Договорная', NULL, 'price_info', 447, '2022-03-15 18:47:50', NULL),
(448, 1, 123, 'location', 'Каменское', NULL, 'location', 448, '2022-03-15 18:47:50', NULL),
(449, 1, 123, 'add_time', 'Сегодня 11:45', NULL, 'add_time', 449, '2022-03-15 18:47:50', NULL),
(450, 1, 124, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 450, '2022-03-15 18:47:50', NULL),
(451, 1, 124, 'location', 'Киев, Подольский', NULL, 'location', 451, '2022-03-15 18:47:50', NULL),
(452, 1, 124, 'add_time', 'Сегодня 11:44', NULL, 'add_time', 452, '2022-03-15 18:47:50', NULL),
(453, 1, 125, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 453, '2022-03-15 18:47:50', NULL),
(454, 1, 125, 'price_info', 'Договорная', NULL, 'price_info', 454, '2022-03-15 18:47:50', NULL),
(455, 1, 125, 'location', 'Тальное', NULL, 'location', 455, '2022-03-15 18:47:50', NULL),
(456, 1, 125, 'add_time', 'Сегодня 11:41', NULL, 'add_time', 456, '2022-03-15 18:47:50', NULL),
(457, 1, 126, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 457, '2022-03-15 18:47:50', NULL),
(458, 1, 126, 'location', 'Киев, Подольский', NULL, 'location', 458, '2022-03-15 18:47:50', NULL),
(459, 1, 126, 'add_time', 'Сегодня 11:39', NULL, 'add_time', 459, '2022-03-15 18:47:50', NULL),
(460, 1, 127, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 460, '2022-03-15 18:47:50', NULL),
(461, 1, 127, 'price_info', 'Договорная', NULL, 'price_info', 461, '2022-03-15 18:47:50', NULL),
(462, 1, 127, 'location', 'Хуст', NULL, 'location', 462, '2022-03-15 18:47:50', NULL),
(463, 1, 127, 'add_time', 'Сегодня 11:38', NULL, 'add_time', 463, '2022-03-15 18:47:50', NULL),
(464, 1, 128, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 464, '2022-03-15 18:47:50', NULL),
(465, 1, 128, 'location', 'Киев, Оболонский', NULL, 'location', 465, '2022-03-15 18:47:50', NULL),
(466, 1, 128, 'add_time', 'Сегодня 11:37', NULL, 'add_time', 466, '2022-03-15 18:47:50', NULL),
(467, 1, 129, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 3 - авто', NULL, 'breadcrumbs', 467, '2022-03-15 18:47:50', NULL),
(468, 1, 129, 'price_info', 'Договорная', NULL, 'price_info', 468, '2022-03-15 18:47:50', NULL),
(469, 1, 129, 'location', 'Ивано-Франковск', NULL, 'location', 469, '2022-03-15 18:47:50', NULL),
(470, 1, 129, 'add_time', 'Сегодня 11:37', NULL, 'add_time', 470, '2022-03-15 18:47:50', NULL),
(471, 1, 130, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 471, '2022-03-15 18:47:50', '2022-03-15 18:47:51'),
(472, 1, 130, 'location', 'Одесса, Киевский', NULL, 'location', 472, '2022-03-15 18:47:50', '2022-03-15 18:47:51'),
(473, 1, 130, 'add_time', 'Сегодня 11:37', NULL, 'add_time', 473, '2022-03-15 18:47:50', '2022-03-15 18:47:51'),
(474, 1, 131, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 474, '2022-03-15 18:47:50', NULL),
(475, 1, 131, 'top', 'yes', NULL, 'top', 475, '2022-03-15 18:47:50', NULL),
(476, 1, 131, 'location', 'Николаев, Ингульский', NULL, 'location', 476, '2022-03-15 18:47:50', NULL),
(477, 1, 131, 'add_time', 'Вчера 15:50', NULL, 'add_time', 477, '2022-03-15 18:47:50', NULL),
(478, 1, 132, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 478, '2022-03-15 18:47:50', NULL),
(479, 1, 132, 'price_info', 'Договорная', NULL, 'price_info', 479, '2022-03-15 18:47:50', NULL),
(480, 1, 132, 'top', 'yes', NULL, 'top', 480, '2022-03-15 18:47:50', NULL),
(481, 1, 132, 'location', 'Каменское', NULL, 'location', 481, '2022-03-15 18:47:50', NULL),
(482, 1, 132, 'add_time', '13  март', NULL, 'add_time', 482, '2022-03-15 18:47:50', NULL),
(483, 1, 133, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 483, '2022-03-15 18:47:50', NULL);
INSERT INTO `fields` (`id`, `typefield_id`, `product_id`, `name`, `value`, `content`, `trans`, `sort`, `created_at`, `updated_at`) VALUES
(484, 1, 133, 'top', 'yes', NULL, 'top', 484, '2022-03-15 18:47:50', NULL),
(485, 1, 133, 'location', 'Николаев, Ингульский', NULL, 'location', 485, '2022-03-15 18:47:50', NULL),
(486, 1, 133, 'add_time', 'Вчера 15:54', NULL, 'add_time', 486, '2022-03-15 18:47:50', NULL),
(487, 1, 134, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 487, '2022-03-15 18:47:51', NULL),
(488, 1, 134, 'location', 'Киев, Подольский', NULL, 'location', 488, '2022-03-15 18:47:51', NULL),
(489, 1, 134, 'add_time', 'Сегодня 11:36', NULL, 'add_time', 489, '2022-03-15 18:47:51', NULL),
(490, 1, 135, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 490, '2022-03-15 18:47:51', NULL),
(491, 1, 135, 'price_info', 'Договорная', NULL, 'price_info', 491, '2022-03-15 18:47:51', NULL),
(492, 1, 135, 'location', 'Переяслав-Хмельницкий', NULL, 'location', 492, '2022-03-15 18:47:51', NULL),
(493, 1, 135, 'add_time', 'Сегодня 11:32', NULL, 'add_time', 493, '2022-03-15 18:47:51', NULL),
(494, 1, 136, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 494, '2022-03-15 18:47:51', NULL),
(495, 1, 136, 'price_info', 'Договорная', NULL, 'price_info', 495, '2022-03-15 18:47:51', NULL),
(496, 1, 136, 'location', 'Ужгород', NULL, 'location', 496, '2022-03-15 18:47:51', NULL),
(497, 1, 136, 'add_time', 'Сегодня 11:31', NULL, 'add_time', 497, '2022-03-15 18:47:51', NULL),
(498, 1, 137, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 498, '2022-03-15 18:47:51', NULL),
(499, 1, 137, 'price_info', 'Договорная', NULL, 'price_info', 499, '2022-03-15 18:47:51', NULL),
(500, 1, 137, 'location', 'Львов, Франковский', NULL, 'location', 500, '2022-03-15 18:47:51', NULL),
(501, 1, 137, 'add_time', 'Сегодня 11:27', NULL, 'add_time', 501, '2022-03-15 18:47:51', NULL),
(502, 1, 138, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 502, '2022-03-15 18:47:51', NULL),
(503, 1, 138, 'price_info', 'Договорная', NULL, 'price_info', 503, '2022-03-15 18:47:51', NULL),
(504, 1, 138, 'top', 'yes', NULL, 'top', 504, '2022-03-15 18:47:51', NULL),
(505, 1, 138, 'location', 'Радехов', NULL, 'location', 505, '2022-03-15 18:47:51', NULL),
(506, 1, 138, 'add_time', 'Сегодня 11:25', NULL, 'add_time', 506, '2022-03-15 18:47:51', NULL),
(507, 1, 139, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 507, '2022-03-15 18:47:51', NULL),
(508, 1, 139, 'location', 'Киев, Подольский', NULL, 'location', 508, '2022-03-15 18:47:51', NULL),
(509, 1, 139, 'add_time', 'Сегодня 11:22', NULL, 'add_time', 509, '2022-03-15 18:47:51', NULL),
(510, 1, 140, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 510, '2022-03-15 18:47:51', NULL),
(511, 1, 140, 'location', 'Киев, Подольский', NULL, 'location', 511, '2022-03-15 18:47:51', NULL),
(512, 1, 140, 'add_time', 'Сегодня 11:20', NULL, 'add_time', 512, '2022-03-15 18:47:51', NULL),
(513, 1, 141, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 513, '2022-03-15 18:47:51', NULL),
(514, 1, 141, 'location', 'Киев, Подольский', NULL, 'location', 514, '2022-03-15 18:47:51', NULL),
(515, 1, 141, 'add_time', 'Сегодня 11:15', NULL, 'add_time', 515, '2022-03-15 18:47:51', NULL),
(516, 1, 142, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 516, '2022-03-15 18:47:51', NULL),
(517, 1, 142, 'location', 'Киев, Подольский', NULL, 'location', 517, '2022-03-15 18:47:51', NULL),
(518, 1, 142, 'add_time', 'Сегодня 11:11', NULL, 'add_time', 518, '2022-03-15 18:47:51', NULL),
(519, 1, 143, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 519, '2022-03-15 18:47:51', NULL),
(520, 1, 143, 'price_info', 'Договорная', NULL, 'price_info', 520, '2022-03-15 18:47:51', NULL),
(521, 1, 143, 'location', 'Зимняя Вода', NULL, 'location', 521, '2022-03-15 18:47:51', NULL),
(522, 1, 143, 'add_time', 'Сегодня 10:49', NULL, 'add_time', 522, '2022-03-15 18:47:51', NULL),
(523, 1, 144, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 523, '2022-03-15 18:47:51', NULL),
(524, 1, 144, 'location', 'Львов, Сиховский', NULL, 'location', 524, '2022-03-15 18:47:51', NULL),
(525, 1, 144, 'add_time', 'Сегодня 10:44', NULL, 'add_time', 525, '2022-03-15 18:47:51', NULL),
(526, 1, 145, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 526, '2022-03-15 18:47:51', NULL),
(527, 1, 145, 'price_info', 'Договорная', NULL, 'price_info', 527, '2022-03-15 18:47:51', NULL),
(528, 1, 145, 'location', 'Киев, Соломенский', NULL, 'location', 528, '2022-03-15 18:47:51', NULL),
(529, 1, 145, 'add_time', 'Сегодня 10:25', NULL, 'add_time', 529, '2022-03-15 18:47:51', NULL),
(530, 1, 146, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 530, '2022-03-15 18:47:51', NULL),
(531, 1, 146, 'price_info', 'Договорная', NULL, 'price_info', 531, '2022-03-15 18:47:51', NULL),
(532, 1, 146, 'location', 'Марьянское', NULL, 'location', 532, '2022-03-15 18:47:51', NULL),
(533, 1, 146, 'add_time', 'Сегодня 10:24', NULL, 'add_time', 533, '2022-03-15 18:47:51', NULL),
(534, 1, 147, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 534, '2022-03-15 18:47:51', NULL),
(535, 1, 147, 'location', 'Луганск, Жовтневый', NULL, 'location', 535, '2022-03-15 18:47:51', NULL),
(536, 1, 147, 'add_time', 'Сегодня 10:07', NULL, 'add_time', 536, '2022-03-15 18:47:51', NULL),
(537, 1, 148, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 537, '2022-03-15 18:47:51', NULL),
(538, 1, 148, 'top', 'yes', NULL, 'top', 538, '2022-03-15 18:47:51', NULL),
(539, 1, 148, 'location', 'Киев, Подольский', NULL, 'location', 539, '2022-03-15 18:47:51', NULL),
(540, 1, 148, 'add_time', 'Сегодня 10:07', NULL, 'add_time', 540, '2022-03-15 18:47:51', NULL),
(541, 1, 149, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 541, '2022-03-15 18:47:51', NULL),
(542, 1, 149, 'location', 'Горишные Плавни', NULL, 'location', 542, '2022-03-15 18:47:51', NULL),
(543, 1, 149, 'add_time', 'Сегодня 10:05', NULL, 'add_time', 543, '2022-03-15 18:47:51', NULL),
(544, 1, 150, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 544, '2022-03-15 18:47:51', NULL),
(545, 1, 150, 'price_info', 'Договорная', NULL, 'price_info', 545, '2022-03-15 18:47:51', NULL),
(546, 1, 150, 'top', 'yes', NULL, 'top', 546, '2022-03-15 18:47:51', NULL),
(547, 1, 150, 'location', 'Радивилов', NULL, 'location', 547, '2022-03-15 18:47:51', NULL),
(548, 1, 150, 'add_time', 'Сегодня 10:01', NULL, 'add_time', 548, '2022-03-15 18:47:51', NULL),
(549, 1, 151, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 549, '2022-03-15 18:47:51', NULL),
(550, 1, 151, 'top', 'yes', NULL, 'top', 550, '2022-03-15 18:47:51', NULL),
(551, 1, 151, 'location', 'Кирнички', NULL, 'location', 551, '2022-03-15 18:47:51', NULL),
(552, 1, 151, 'add_time', 'Сегодня 10:00', NULL, 'add_time', 552, '2022-03-15 18:47:51', NULL),
(553, 1, 152, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 553, '2022-03-15 18:47:51', NULL),
(554, 1, 152, 'price_info', 'Договорная', NULL, 'price_info', 554, '2022-03-15 18:47:51', NULL),
(555, 1, 152, 'location', 'Елизаветградка', NULL, 'location', 555, '2022-03-15 18:47:51', NULL),
(556, 1, 152, 'add_time', 'Сегодня 09:54', NULL, 'add_time', 556, '2022-03-15 18:47:51', NULL),
(557, 1, 153, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 557, '2022-03-15 18:47:51', NULL),
(558, 1, 153, 'location', 'Новоград-Волынский', NULL, 'location', 558, '2022-03-15 18:47:51', NULL),
(559, 1, 153, 'add_time', 'Сегодня 09:52', NULL, 'add_time', 559, '2022-03-15 18:47:51', NULL),
(560, 1, 154, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 560, '2022-03-15 18:47:51', NULL),
(561, 1, 154, 'price_info', 'Договорная', NULL, 'price_info', 561, '2022-03-15 18:47:51', NULL),
(562, 1, 154, 'top', 'yes', NULL, 'top', 562, '2022-03-15 18:47:51', NULL),
(563, 1, 154, 'location', 'Кодыма', NULL, 'location', 563, '2022-03-15 18:47:51', NULL),
(564, 1, 154, 'add_time', 'Сегодня 09:48', NULL, 'add_time', 564, '2022-03-15 18:47:51', NULL),
(565, 1, 155, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 565, '2022-03-15 18:47:51', NULL),
(566, 1, 155, 'top', 'yes', NULL, 'top', 566, '2022-03-15 18:47:51', NULL),
(567, 1, 155, 'location', 'Вишневое', NULL, 'location', 567, '2022-03-15 18:47:51', NULL),
(568, 1, 155, 'add_time', 'Сегодня 09:40', NULL, 'add_time', 568, '2022-03-15 18:47:51', NULL),
(569, 1, 156, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 569, '2022-03-15 18:47:51', NULL),
(570, 1, 156, 'price_info', 'Договорная', NULL, 'price_info', 570, '2022-03-15 18:47:51', NULL),
(571, 1, 156, 'location', 'Ровно', NULL, 'location', 571, '2022-03-15 18:47:51', NULL),
(572, 1, 156, 'add_time', 'Сегодня 09:37', NULL, 'add_time', 572, '2022-03-15 18:47:51', NULL),
(573, 1, 157, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 573, '2022-03-15 18:47:51', NULL),
(574, 1, 157, 'price_info', 'Договорная', NULL, 'price_info', 574, '2022-03-15 18:47:51', NULL),
(575, 1, 157, 'location', 'Старобельск', NULL, 'location', 575, '2022-03-15 18:47:51', NULL),
(576, 1, 157, 'add_time', 'Сегодня 09:26', NULL, 'add_time', 576, '2022-03-15 18:47:51', NULL),
(577, 1, 158, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 577, '2022-03-15 18:47:51', NULL),
(578, 1, 158, 'price_info', 'Договорная', NULL, 'price_info', 578, '2022-03-15 18:47:51', NULL),
(579, 1, 158, 'top', 'yes', NULL, 'top', 579, '2022-03-15 18:47:51', NULL),
(580, 1, 158, 'location', 'Ваневичи', NULL, 'location', 580, '2022-03-15 18:47:51', NULL),
(581, 1, 158, 'add_time', 'Сегодня 09:14', NULL, 'add_time', 581, '2022-03-15 18:47:51', NULL),
(582, 1, 159, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 582, '2022-03-15 18:47:51', NULL),
(583, 1, 159, 'location', 'Днепр, Индустриальный', NULL, 'location', 583, '2022-03-15 18:47:51', NULL),
(584, 1, 159, 'add_time', 'Сегодня 09:12', NULL, 'add_time', 584, '2022-03-15 18:47:51', NULL),
(585, 1, 160, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 585, '2022-03-15 18:47:51', NULL),
(586, 1, 160, 'price_info', 'Договорная', NULL, 'price_info', 586, '2022-03-15 18:47:51', NULL),
(587, 1, 160, 'location', 'Хмельницкий', NULL, 'location', 587, '2022-03-15 18:47:51', NULL),
(588, 1, 160, 'add_time', 'Сегодня 09:12', NULL, 'add_time', 588, '2022-03-15 18:47:51', NULL),
(589, 1, 161, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 589, '2022-03-15 18:47:51', NULL),
(590, 1, 161, 'location', 'Львов, Железнодорожный', NULL, 'location', 590, '2022-03-15 18:47:51', NULL),
(591, 1, 161, 'add_time', 'Сегодня 09:07', NULL, 'add_time', 591, '2022-03-15 18:47:51', NULL),
(592, 1, 162, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 592, '2022-03-15 18:47:51', NULL),
(593, 1, 162, 'location', 'Одесса, Малиновский', NULL, 'location', 593, '2022-03-15 18:47:51', NULL),
(594, 1, 162, 'add_time', 'Сегодня 09:07', NULL, 'add_time', 594, '2022-03-15 18:47:51', NULL),
(595, 1, 163, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 595, '2022-03-15 18:47:51', NULL),
(596, 1, 163, 'location', 'Одесса, Малиновский', NULL, 'location', 596, '2022-03-15 18:47:51', NULL),
(597, 1, 163, 'add_time', 'Сегодня 09:06', NULL, 'add_time', 597, '2022-03-15 18:47:51', NULL),
(598, 1, 164, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 598, '2022-03-15 18:47:51', NULL),
(599, 1, 164, 'price_info', 'Договорная', NULL, 'price_info', 599, '2022-03-15 18:47:51', NULL),
(600, 1, 164, 'location', 'Зборов', NULL, 'location', 600, '2022-03-15 18:47:51', NULL),
(601, 1, 164, 'add_time', 'Сегодня 08:53', NULL, 'add_time', 601, '2022-03-15 18:47:51', NULL),
(602, 1, 165, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 602, '2022-03-15 18:47:51', NULL),
(603, 1, 165, 'price_info', 'Договорная', NULL, 'price_info', 603, '2022-03-15 18:47:51', NULL),
(604, 1, 165, 'location', 'Киев, Шевченковский', NULL, 'location', 604, '2022-03-15 18:47:51', NULL),
(605, 1, 165, 'add_time', 'Сегодня 07:47', NULL, 'add_time', 605, '2022-03-15 18:47:51', NULL),
(606, 1, 166, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 606, '2022-03-15 18:47:51', NULL),
(607, 1, 166, 'price_info', 'Договорная', NULL, 'price_info', 607, '2022-03-15 18:47:51', NULL),
(608, 1, 166, 'location', 'Черкассы', NULL, 'location', 608, '2022-03-15 18:47:51', NULL),
(609, 1, 166, 'add_time', 'Сегодня 07:41', NULL, 'add_time', 609, '2022-03-15 18:47:51', NULL),
(610, 1, 167, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 610, '2022-03-15 18:47:51', NULL),
(611, 1, 167, 'price_info', 'Договорная', NULL, 'price_info', 611, '2022-03-15 18:47:51', NULL),
(612, 1, 167, 'location', 'Мариуполь', NULL, 'location', 612, '2022-03-15 18:47:51', NULL),
(613, 1, 167, 'add_time', 'Сегодня 07:37', NULL, 'add_time', 613, '2022-03-15 18:47:51', NULL),
(614, 1, 168, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 614, '2022-03-15 18:47:51', NULL),
(615, 1, 168, 'location', 'Полтава', NULL, 'location', 615, '2022-03-15 18:47:51', NULL),
(616, 1, 168, 'add_time', 'Сегодня 07:36', NULL, 'add_time', 616, '2022-03-15 18:47:51', NULL),
(617, 1, 169, 'breadcrumbs', 'Авто/Легковые автомобили/Продажа авто - страница 4 - авто', NULL, 'breadcrumbs', 617, '2022-03-15 18:47:51', NULL),
(618, 1, 169, 'location', 'Одесса, Суворовский', NULL, 'location', 618, '2022-03-15 18:47:51', NULL),
(619, 1, 169, 'add_time', 'Сегодня 07:18', NULL, 'add_time', 619, '2022-03-15 18:47:51', NULL),
(620, 1, 170, 'breadcrumbs', 'Авто/Легковые автомобили/Peugeot/Peugeot - Одесская область/Peugeot - Одесса/Peugeot - Суворовский', NULL, 'breadcrumbs', 620, '2022-03-15 18:47:51', '2022-03-18 07:08:53'),
(621, 1, 170, 'location', 'Одесская область, Одесса, Суворовский', NULL, 'location', 621, '2022-03-15 18:47:51', '2022-03-18 07:08:55'),
(622, 1, 170, 'add_time', 'Сегодня 07:18', NULL, 'add_time', 622, '2022-03-15 18:47:51', NULL),
(623, 2, 170, 'Модель', '307', NULL, 'model', 623, '2022-03-17 14:45:24', '2022-03-18 07:08:53'),
(624, 2, 170, 'Тип автомобиля', 'С пробегом', NULL, 'tip_avtomobilya', 624, '2022-03-17 14:45:25', '2022-03-18 07:08:53'),
(625, 2, 170, 'Условия продажи', 'Простая продажа', NULL, 'usloviya_prodazhi', 625, '2022-03-17 14:45:25', '2022-03-18 07:08:53'),
(626, 2, 170, 'Растаможена', 'Да', NULL, 'rastamozhena', 626, '2022-03-17 14:45:25', '2022-03-18 07:08:53'),
(627, 2, 170, 'Год выпуска', '2003', NULL, 'god_vypuska', 627, '2022-03-17 14:45:25', '2022-03-18 07:08:53'),
(628, 2, 170, 'Пробег', '236 000 км', NULL, 'probeg', 628, '2022-03-17 14:45:26', '2022-03-18 07:08:54'),
(629, 2, 170, 'Тип кузова', 'Универсал', NULL, 'tip_kuzova', 629, '2022-03-17 14:45:26', '2022-03-18 07:08:54'),
(630, 2, 170, 'Количество дверей', '5', NULL, 'kolichestvo_dverey', 630, '2022-03-17 14:45:27', '2022-03-18 07:08:54'),
(631, 2, 170, 'Цвет', 'Бирюзовый', NULL, 'cvet', 631, '2022-03-17 14:45:27', '2022-03-18 07:08:54'),
(632, 2, 170, 'Коробка передач', 'Автоматическая', NULL, 'korobka_peredach', 632, '2022-03-17 14:45:27', '2022-03-18 07:08:54'),
(633, 2, 170, 'Тип привода', 'Передний', NULL, 'tip_privoda', 633, '2022-03-17 14:45:28', '2022-03-18 07:08:54'),
(634, 2, 170, 'Вид топлива', 'Бензин', NULL, 'vid_topliva', 634, '2022-03-17 14:45:28', '2022-03-18 07:08:54'),
(635, 2, 170, 'Объем двигателя', '16 см³', NULL, 'obem_dvigatelya', 635, '2022-03-17 14:45:28', '2022-03-18 07:08:54'),
(636, 2, 170, 'Лакокрасочное покрытие', 'Незначительные следы эксплуатации (мелкие царапины, сколы)', NULL, 'lakokrasochnoe_pokrytie', 636, '2022-03-17 14:45:28', '2022-03-18 07:08:54'),
(637, 2, 170, 'Техническое состояние', 'На ходу, технически исправна, Не бита, Не крашена', NULL, 'tehnicheskoe_sostoyanie', 637, '2022-03-17 14:45:29', '2022-03-18 07:08:54'),
(638, 2, 170, 'Комфорт', 'Кондиционер, Климат контроль, Электропакет, Эл. стеклоподъемники, Тонирование стёкол, Подогрев зеркал, Бортовой компьютер, Панорамная крыша, Усилитель руля, Датчик дождя', NULL, 'komfort', 638, '2022-03-17 14:45:29', '2022-03-18 07:08:54'),
(639, 2, 170, 'Мультимедиа', 'Акустика, AUX, Bluetooth, CD, Магнитола', NULL, 'multimedia', 639, '2022-03-17 14:45:29', '2022-03-18 07:08:54'),
(640, 2, 170, 'Безопасность', 'ABD, ABS, Подушка безопасности (Airbag), Центральный замок, ESP, Иммобилайзер', NULL, 'bezopasnost', 640, '2022-03-17 14:45:30', '2022-03-18 07:08:54'),
(641, 2, 170, 'Прочее', 'Фаркоп', NULL, 'prochee', 641, '2022-03-17 14:45:30', '2022-03-18 07:08:55'),
(642, 2, 170, 'location', 'Одесская область, Одесса, Суворовский', NULL, 'location', 642, '2022-03-17 15:08:53', '2022-03-17 15:09:13'),
(643, 2, 170, 'phone', '380967255918', NULL, 'phone', 643, '2022-03-17 15:08:55', '2022-03-17 15:09:13'),
(644, 2, 170, 'user', '380967255918', NULL, 'user', 644, '2022-03-17 15:08:55', '2022-03-17 15:09:14'),
(645, 1, 170, 'phone', '380967255918', NULL, 'phone', 645, '2022-03-17 15:09:32', '2022-03-18 07:08:55'),
(646, 1, 170, 'user', '380967255918', NULL, 'user', 646, '2022-03-17 15:09:32', '2022-03-18 07:08:55');

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--
-- Создание: Фев 09 2022 г., 12:39
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ru` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shortname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_active` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `languages`
--

INSERT INTO `languages` (`id`, `name`, `name_ru`, `name_en`, `shortname`, `created_at`, `updated_at`, `is_active`) VALUES
(1, 'Русский', 'Русский', 'Russian', 'ru', '2020-03-28 11:37:33', '2020-03-28 11:37:33', 1),
(2, 'Українська', 'Украинский', 'Ukrainian', 'uk', '2020-03-28 11:49:20', '2020-03-28 11:49:20', 1),
(3, 'English', 'Английский', 'English', 'en', '2020-03-28 11:49:37', '2020-03-28 11:49:37', 0),
(4, '中国人', 'Китайский', 'Chinese', 'zh', '2020-03-28 14:53:08', '2020-03-28 14:53:08', 0),
(5, 'عربي', 'Арабский', 'Arab', 'ar', '2020-03-28 14:56:08', '2020-03-28 14:56:08', 0),
(6, NULL, 'Абхазский', 'Abkhazian', 'ab', '2020-04-02 08:30:31', NULL, 0),
(7, NULL, 'Аварский', 'Avaric', 'av', '2020-04-02 08:30:31', NULL, 0),
(8, NULL, 'Авестийский', 'Avestan', 'ae', '2020-04-02 08:30:31', NULL, 0),
(9, NULL, 'Азербайджанский', 'Azerbaijani', 'az', '2020-04-02 08:30:31', NULL, 0),
(10, NULL, 'Аймара', 'Aymara', 'ay', '2020-04-02 08:30:31', NULL, 0),
(11, NULL, 'Акан', 'Akan', 'ak', '2020-04-02 08:30:31', NULL, 0),
(12, NULL, 'Албанский', 'Albanian', 'sq', '2020-04-02 08:30:31', NULL, 0),
(13, NULL, 'Амхарский', 'Amharic', 'am', '2020-04-02 08:30:31', NULL, 0),
(14, NULL, 'Армянский', 'Armenian', 'hy', '2020-04-02 08:30:31', NULL, 0),
(15, NULL, 'Ассамский', 'Assamese', 'as', '2020-04-02 08:30:31', NULL, 0),
(16, NULL, 'Афарский', 'Afar', 'aa', '2020-04-02 08:30:31', NULL, 0),
(17, NULL, 'Африкаанс', 'Afrikaans', 'af', '2020-04-02 08:30:31', NULL, 0),
(18, NULL, 'Бамбара', 'Bambara', 'bm', '2020-04-02 08:30:31', NULL, 0),
(19, NULL, 'Баскский', 'Basque', 'eu', '2020-04-02 08:30:31', NULL, 0),
(20, NULL, 'Башкирский', 'Bashkir', 'ba', '2020-04-02 08:30:31', NULL, 0),
(21, NULL, 'Белорусский', 'Belarusian', 'be', '2020-04-02 08:30:31', NULL, 0),
(22, NULL, 'Бенгальский', 'Bengali', 'bn', '2020-04-02 08:30:31', NULL, 0),
(23, NULL, 'Бирманский', 'Burmese', 'my', '2020-04-02 08:30:31', NULL, 0),
(24, NULL, 'Бислама', 'Bislama', 'bi', '2020-04-02 08:30:31', NULL, 0),
(25, NULL, 'Болгарский', 'Bulgarian', 'bg', '2020-04-02 08:30:31', NULL, 0),
(26, NULL, 'Боснийский', 'Bosnian', 'bs', '2020-04-02 08:30:31', NULL, 0),
(27, NULL, 'Бретонский', 'Breton', 'br', '2020-04-02 08:30:31', NULL, 0),
(28, NULL, 'Валлийский', 'Welsh', 'cy', '2020-04-02 08:30:31', NULL, 0),
(29, NULL, 'Венгерский', 'Hungarian', 'hu', '2020-04-02 08:30:31', NULL, 0),
(30, NULL, 'Венда', 'Venda', 've', '2020-04-02 08:30:31', NULL, 0),
(31, NULL, 'Волапюк', 'Volapuk', 'vo', '2020-04-02 08:30:31', NULL, 0),
(32, NULL, 'Волоф', 'Wolof', 'wo', '2020-04-02 08:30:31', NULL, 0),
(33, NULL, 'Вьетнамский', 'Vietnamese', 'vi', '2020-04-02 08:30:31', NULL, 0),
(34, NULL, 'Галисийский', 'Galician', 'gl', '2020-04-02 08:30:31', NULL, 0),
(35, NULL, 'Ганда', 'Luganda', 'lg', '2020-04-02 08:30:31', NULL, 0),
(36, NULL, 'Гереро', 'Herero', 'hz', '2020-04-02 08:30:31', NULL, 0),
(37, NULL, 'Гренландский', 'Kalaallisut', 'kl', '2020-04-02 08:30:31', NULL, 0),
(38, NULL, 'Греческий', 'Greek', 'el', '2020-04-02 08:30:31', NULL, 0),
(39, NULL, 'Грузинский', 'Georgian', 'ka', '2020-04-02 08:30:31', NULL, 0),
(40, NULL, 'Гуарани', 'Guarani', 'gn', '2020-04-02 08:30:31', NULL, 0),
(41, NULL, 'Гуджарати', 'Gujarati', 'gu', '2020-04-02 08:30:31', NULL, 0),
(42, NULL, 'Гэльский', 'Gaelic', 'gd', '2020-04-02 08:30:31', NULL, 0),
(43, NULL, 'Датский', 'Danish', 'da', '2020-04-02 08:30:31', NULL, 0),
(44, NULL, 'Дзонг-кэ', 'Dzongkha', 'dz', '2020-04-02 08:30:31', NULL, 0),
(45, NULL, 'Дивехи', 'Divehi', 'dv', '2020-04-02 08:30:31', NULL, 0),
(46, NULL, 'Зулу', 'Zulu', 'zu', '2020-04-02 08:30:31', NULL, 0),
(47, NULL, 'Иврит', 'Hebrew', 'he', '2020-04-02 08:30:31', NULL, 0),
(48, NULL, 'Игбо', 'Igbo', 'ig', '2020-04-02 08:30:31', NULL, 0),
(49, NULL, 'Идиш', 'Yiddish', 'yi', '2020-04-02 08:30:31', NULL, 0),
(50, NULL, 'Индонезийский', 'Indonesian', 'id', '2020-04-02 08:30:31', NULL, 0),
(51, NULL, 'Интерлингва', 'Interlingua', 'ia', '2020-04-02 08:30:31', NULL, 0),
(52, NULL, 'Интерлингве', 'Interlingue', 'ie', '2020-04-02 08:30:31', NULL, 0),
(53, NULL, 'Инуктитут', 'Inuktitut', 'iu', '2020-04-02 08:30:31', NULL, 0),
(54, NULL, 'Инупиак', 'Inupiak', 'ik', '2020-04-02 08:30:31', NULL, 0),
(55, NULL, 'Ирландский', 'Irish', 'ga', '2020-04-02 08:30:31', NULL, 0),
(56, NULL, 'Исландский', 'Icelandic', 'is', '2020-04-02 08:30:31', NULL, 0),
(57, NULL, 'Испанский', 'Spanish', 'es', '2020-04-02 08:30:31', NULL, 0),
(58, NULL, 'Итальянский', 'Italian', 'it', '2020-04-02 08:30:31', NULL, 0),
(59, NULL, 'Йоруба', 'Yoruba', 'yo', '2020-04-02 08:30:31', NULL, 0),
(60, NULL, 'Казахский', 'Kazakh', 'kk', '2020-04-02 08:30:31', NULL, 0),
(61, NULL, 'Каннада', 'Kannada', 'kn', '2020-04-02 08:30:31', NULL, 0),
(62, NULL, 'Канури', 'Kanuri', 'kr', '2020-04-02 08:30:31', NULL, 0),
(63, NULL, 'Каталанский', 'Catalan', 'ca', '2020-04-02 08:30:31', NULL, 0),
(64, NULL, 'Кашмири', 'Kashmiri', 'ks', '2020-04-02 08:30:31', NULL, 0),
(65, NULL, 'Кечуа', 'Quechua', 'qu', '2020-04-02 08:30:31', NULL, 0),
(66, NULL, 'Кикуйю', 'Kikuyu', 'ki', '2020-04-02 08:30:31', NULL, 0),
(67, NULL, 'Киньяма', 'Kwanyama', 'kj', '2020-04-02 08:30:31', NULL, 0),
(68, NULL, 'Киргизский', 'Kyrgyz', 'ky', '2020-04-02 08:30:31', NULL, 0),
(69, NULL, 'Коми', 'Komi', 'kv', '2020-04-02 08:30:31', NULL, 0),
(70, NULL, 'Конго', 'Kongo', 'kg', '2020-04-02 08:30:31', NULL, 0),
(71, NULL, 'Корейский', 'Korean', 'ko', '2020-04-02 08:30:31', NULL, 0),
(72, NULL, 'Корнский', 'Cornish', 'kw', '2020-04-02 08:30:31', NULL, 0),
(73, NULL, 'Корсиканский', 'Corsican', 'co', '2020-04-02 08:30:31', NULL, 0),
(74, NULL, 'Коса', 'Xhosa', 'xh', '2020-04-02 08:30:31', NULL, 0),
(75, NULL, 'Курдский', 'Kurdish', 'ku', '2020-04-02 08:30:31', NULL, 0),
(76, NULL, 'Кхмерский', 'Khmer', 'km', '2020-04-02 08:30:31', NULL, 0),
(77, NULL, 'Лаосский', 'Lao', 'lo', '2020-04-02 08:30:31', NULL, 0),
(78, NULL, 'Латинский', 'Latin', 'la', '2020-04-02 08:30:31', NULL, 0),
(79, NULL, 'Латышский', 'Latvian', 'lv', '2020-04-02 08:30:31', NULL, 0),
(80, NULL, 'Лингала', 'Lingala', 'ln', '2020-04-02 08:30:31', NULL, 0),
(81, NULL, 'Литовский', 'Lithuanian', 'lt', '2020-04-02 08:30:31', NULL, 0),
(82, NULL, 'Луба-катанга', 'Luga-Katanga', 'lu', '2020-04-02 08:30:31', NULL, 0),
(83, NULL, 'Люксембургский', 'Luxembourgish', 'lb', '2020-04-02 08:30:31', NULL, 0),
(84, NULL, 'Македонский', 'Macedonian', 'mk', '2020-04-02 08:30:31', NULL, 0),
(85, NULL, 'Малагасийский', 'Malagasy', 'mg', '2020-04-02 08:30:31', NULL, 0),
(86, NULL, 'Малайский', 'Malay', 'ms', '2020-04-02 08:30:31', NULL, 0),
(87, NULL, 'Малаялам', 'Malayalam', 'ml', '2020-04-02 08:30:31', NULL, 0),
(88, NULL, 'Мальтийский', 'Maltese', 'mt', '2020-04-02 08:30:31', NULL, 0),
(89, NULL, 'Маори', 'Maori', 'mi', '2020-04-02 08:30:31', NULL, 0),
(90, NULL, 'Маратхи', 'Marathi', 'mr', '2020-04-02 08:30:31', NULL, 0),
(91, NULL, 'Маршалльский', 'Marshallese', 'mh', '2020-04-02 08:30:31', NULL, 0),
(92, NULL, 'Монгольский', 'Mongolian', 'mn', '2020-04-02 08:30:31', NULL, 0),
(93, NULL, 'Мэнский', 'Manx', 'gv', '2020-04-02 08:30:31', NULL, 0),
(94, NULL, 'Навахо', 'Navajo', 'nv', '2020-04-02 08:30:31', NULL, 0),
(95, NULL, 'Науру', 'Nauru', 'na', '2020-04-02 08:30:31', NULL, 0),
(96, NULL, 'Ндебелесеверный', 'NorthernNdebele', 'nd', '2020-04-02 08:30:31', NULL, 0),
(97, NULL, 'Ндебелеюжный', 'SouthernNdebele', 'nr', '2020-04-02 08:30:31', NULL, 0),
(98, NULL, 'Ндунга', 'Ndonga', 'ng', '2020-04-02 08:30:31', NULL, 0),
(99, NULL, 'Немецкий', 'German', 'de', '2020-04-02 08:30:31', NULL, 0),
(100, NULL, 'Непальский', 'Nepali', 'ne', '2020-04-02 08:30:31', NULL, 0),
(101, NULL, 'Нидерландский', 'Dutch', 'nl', '2020-04-02 08:30:31', NULL, 0),
(102, NULL, 'Норвежский', 'Norwegian', 'no', '2020-04-02 08:30:31', NULL, 0),
(103, NULL, 'Ньянджа', 'Chichewa', 'ny', '2020-04-02 08:30:31', NULL, 0),
(104, NULL, 'Нюнорск', 'Norwegiannynorsk', 'nn', '2020-04-02 08:30:31', NULL, 0),
(105, NULL, 'Оджибве', 'Ojibwe', 'oj', '2020-04-02 08:30:31', NULL, 0),
(106, NULL, 'Окситанский', 'Occitan', 'oc', '2020-04-02 08:30:31', NULL, 0),
(107, NULL, 'Ория', 'Oriya', 'or', '2020-04-02 08:30:31', NULL, 0),
(108, NULL, 'Оромо', 'Oromo', 'om', '2020-04-02 08:30:31', NULL, 0),
(109, NULL, 'Осетинский', 'Ossetian', 'os', '2020-04-02 08:30:31', NULL, 0),
(110, NULL, 'Пали', 'Pali', 'pi', '2020-04-02 08:30:31', NULL, 0),
(111, NULL, 'Пенджабский', 'Punjabi', 'pa', '2020-04-02 08:30:31', NULL, 0),
(112, NULL, 'Персидский', 'Persian', 'fa', '2020-04-02 08:30:31', NULL, 0),
(113, NULL, 'Польский', 'Polish', 'pl', '2020-04-02 08:30:31', NULL, 0),
(114, NULL, 'Португальский', 'Portuguese', 'pt', '2020-04-02 08:30:31', NULL, 0),
(115, NULL, 'Пушту', 'Pashto', 'ps', '2020-04-02 08:30:31', NULL, 0),
(116, NULL, 'Ретороманский', 'Romansh', 'rm', '2020-04-02 08:30:31', NULL, 0),
(117, NULL, 'Руанда', 'Kinyarwanda', 'rw', '2020-04-02 08:30:31', NULL, 0),
(118, NULL, 'Румынский', 'Romanian', 'ro', '2020-04-02 08:30:31', NULL, 0),
(119, NULL, 'Рунди', 'Kirundi', 'rn', '2020-04-02 08:30:31', NULL, 0),
(120, NULL, 'Самоанский', 'Samoan', 'sm', '2020-04-02 08:30:31', NULL, 0),
(121, NULL, 'Санго', 'Sango', 'sg', '2020-04-02 08:30:31', NULL, 0),
(122, NULL, 'Санскрит', 'Sanskrit', 'sa', '2020-04-02 08:30:31', NULL, 0),
(123, NULL, 'Сардинский', 'Sarda', 'sc', '2020-04-02 08:30:31', NULL, 0),
(124, NULL, 'Свази', 'Swati', 'ss', '2020-04-02 08:30:31', NULL, 0),
(125, NULL, 'Сербский', 'Serbian', 'sr', '2020-04-02 08:30:31', NULL, 0),
(126, NULL, 'Сингальский', 'Sinhalese', 'si', '2020-04-02 08:30:31', NULL, 0),
(127, NULL, 'Синдхи', 'Sindhi', 'sd', '2020-04-02 08:30:31', NULL, 0),
(128, NULL, 'Словацкий', 'Slovak', 'sk', '2020-04-02 08:30:31', NULL, 0),
(129, NULL, 'Словенский', 'Slovenian', 'sl', '2020-04-02 08:30:31', NULL, 0),
(130, NULL, 'Сомали', 'Somali', 'so', '2020-04-02 08:30:31', NULL, 0),
(131, NULL, 'Сотоюжный', 'Sesotho', 'st', '2020-04-02 08:30:31', NULL, 0),
(132, NULL, 'Суах', 'Swahili', 'sw', '2020-04-02 08:30:31', NULL, 0),
(133, NULL, 'Сунданский', 'Sundanese', 'su', '2020-04-02 08:30:31', NULL, 0),
(134, NULL, 'Тагальский', 'Tagalog', 'tl', '2020-04-02 08:30:31', NULL, 0),
(135, NULL, 'Таджикский', 'Tajik', 'tg', '2020-04-02 08:30:31', NULL, 0),
(136, NULL, 'Тайский', 'Thai', 'th', '2020-04-02 08:30:31', NULL, 0),
(137, NULL, 'Таитянский', 'Tahitian', 'ty', '2020-04-02 08:30:31', NULL, 0),
(138, NULL, 'Тамильский', 'Tamil', 'ta', '2020-04-02 08:30:31', NULL, 0),
(139, NULL, 'Татарский', 'Tatar', 'tt', '2020-04-02 08:30:31', NULL, 0),
(140, NULL, 'Тви', 'Twi', 'tw', '2020-04-02 08:30:31', NULL, 0),
(141, NULL, 'Телугу', 'Telugu', 'te', '2020-04-02 08:30:31', NULL, 0),
(142, NULL, 'Тибетский', 'Tibetan', 'bo', '2020-04-02 08:30:31', NULL, 0),
(143, NULL, 'Тигринья', 'Tigrinya', 'ti', '2020-04-02 08:30:31', NULL, 0),
(144, NULL, 'Тонганский', 'Tonga', 'to', '2020-04-02 08:30:31', NULL, 0),
(145, NULL, 'Тсвана', 'Setswana', 'tn', '2020-04-02 08:30:31', NULL, 0),
(146, NULL, 'Тсонга', 'Tsonga', 'ts', '2020-04-02 08:30:31', NULL, 0),
(147, NULL, 'Турецкий', 'Turkish', 'tr', '2020-04-02 08:30:31', NULL, 0),
(148, NULL, 'Туркменский', 'Turkmen', 'tk', '2020-04-02 08:30:31', NULL, 0),
(149, NULL, 'Узбекский', 'Uzbek', 'uz', '2020-04-02 08:30:31', NULL, 0),
(150, NULL, 'Уйгурский', 'Uyghur', 'ug', '2020-04-02 08:30:31', NULL, 0),
(151, NULL, 'Урду', 'Urdu', 'ur', '2020-04-02 08:30:31', NULL, 0),
(152, NULL, 'Фарерский', 'Faroese', 'fo', '2020-04-02 08:30:31', NULL, 0),
(153, NULL, 'Фиджи', 'Fijian', 'fj', '2020-04-02 08:30:31', NULL, 0),
(154, NULL, 'Ф', 'Pilipino', 'fl', '2020-04-02 08:30:31', NULL, 0),
(155, NULL, 'Финский', 'Finnish', 'fi', '2020-04-02 08:30:31', NULL, 0),
(156, NULL, 'Французский', 'French', 'fr', '2020-04-02 08:30:31', NULL, 0),
(157, NULL, 'Фризский', 'WesternFrisian', 'fy', '2020-04-02 08:30:31', NULL, 0),
(158, NULL, 'Фулах', 'Fula', 'ff', '2020-04-02 08:30:31', NULL, 0),
(159, NULL, 'Хауса', 'Hausa', 'ha', '2020-04-02 08:30:31', NULL, 0),
(160, NULL, 'Хинди', 'Hindi', 'hi', '2020-04-02 08:30:31', NULL, 0),
(161, NULL, 'Хиримоту', 'HiriMotu', 'ho', '2020-04-02 08:30:31', NULL, 0),
(162, NULL, 'Хорватский', 'Croatian', 'hr', '2020-04-02 08:30:31', NULL, 0),
(163, NULL, 'Церковнославянский', 'OldChurchSlavonic', 'cu', '2020-04-02 08:30:31', NULL, 0),
(164, NULL, 'Чаморро', 'Chamorro', 'ch', '2020-04-02 08:30:31', NULL, 0),
(165, NULL, 'Чеченский', 'Chechen', 'ce', '2020-04-02 08:30:31', NULL, 0),
(166, NULL, 'Чешский', 'Czech', 'cs', '2020-04-02 08:30:31', NULL, 0),
(167, NULL, 'Чжуанский', 'Zhuang', 'za', '2020-04-02 08:30:31', NULL, 0),
(168, NULL, 'Чувашский', 'Chuvash', 'cv', '2020-04-02 08:30:31', NULL, 0),
(169, NULL, 'Шведский', 'Swedish', 'sv', '2020-04-02 08:30:31', NULL, 0),
(170, NULL, 'Шона', 'Shona', 'sn', '2020-04-02 08:30:31', NULL, 0),
(171, NULL, 'Эве', 'Ewe', 'ee', '2020-04-02 08:30:31', NULL, 0),
(172, NULL, 'Эсперанто', 'Esperanto', 'eo', '2020-04-02 08:30:31', NULL, 0),
(173, NULL, 'Эстонский', 'Estonian', 'et', '2020-04-02 08:30:31', NULL, 0),
(174, NULL, 'Яванский', 'Javanese', 'jv', '2020-04-02 08:30:31', NULL, 0),
(175, NULL, 'Японский', 'Japanese', 'ja', '2020-04-02 08:30:31', NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--
-- Создание: Мар 05 2022 г., 20:38
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `area_id` int(10) UNSIGNED DEFAULT NULL,
  `url_id` int(10) UNSIGNED DEFAULT NULL,
  `pid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `images` text COLLATE utf8_unicode_ci,
  `price` float DEFAULT NULL,
  `trans` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` float NOT NULL DEFAULT '1',
  `data` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `area_id`, `url_id`, `pid`, `url`, `name`, `description`, `images`, `price`, `trans`, `sort`, `data`, `created_at`, `updated_at`, `currency_id`) VALUES
(1, 7, 13, '742991780', 'https://www.olx.ua/d/obyavlenie/golf-4-1-6-mpi-2004-god-iz-germanii-sostoyanie-novogo-avto-IDOhv6o.html', 'Golf 4, 1.6 mpi, 2004 год, из Германии, состояние нового авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/xprd8uc15ss8-UA\\/image;s=644x461\"]', 154248, 'golf_4_1_6_mpi_2004_god_iz_germanii_sostoyanie_novogo_avto', 1, NULL, '2022-03-15 18:47:47', NULL, 1),
(2, 7, 13, '742929172', 'https://www.olx.ua/d/obyavlenie/avto-seat-inca-1-9-dizel-IDOhfOA.html', 'Авто  Seat Inca.  1.9 Дизель', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/d5dlkok9yyur1-UA\\/image;s=644x461\"]', 76390, 'avto_seat_inca_1_9_dizel', 2, NULL, '2022-03-15 18:47:47', '2022-03-15 18:47:50', 1),
(3, 7, 13, '742864069', 'https://www.olx.ua/d/obyavlenie/avto-ford-c-max-2004-IDOgYSx.html', 'Авто Ford C-Max 2004', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/thxzp6alq76x2-UA\\/image;s=644x461\"]', 132213, 'avto_ford_c_max_2004', 3, NULL, '2022-03-15 18:47:47', NULL, 1),
(4, 7, 13, '733111248', 'https://www.olx.ua/d/obyavlenie/prodam-avto-shkoda-superb-IDNC3IY.html', 'Продам авто Шкода Суперб', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/042x2u52bijc3-UA\\/image;s=644x461\"]', 132213, 'prodam_avto_shkoda_superb', 4, NULL, '2022-03-15 18:47:47', NULL, 1),
(5, 7, 13, '731537476', 'https://www.olx.ua/d/obyavlenie/prodayu-avto-kia-picanto-IDNwsjy.html', 'Продаю авто KIA PICANTO', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/94z40sue6lwi-UA\\/image;s=644x461\"]', 132213, 'prodayu_avto_kia_picanto', 5, NULL, '2022-03-15 18:47:47', NULL, 1),
(6, 7, 13, '743102607', 'https://www.olx.ua/d/obyavlenie/prodam-avto-dacia-logan-2008-IDOhYWW.html', 'Продам Авто  Dacia Logan 2008', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/fbaq6aak0ni71-UA\\/image;s=644x461\"]', 99894, 'prodam_avto_dacia_logan_2008', 6, NULL, '2022-03-15 18:47:47', NULL, 1),
(7, 7, 13, '740738161', 'https://www.olx.ua/d/obyavlenie/avto-v-horoshomu-stan-IDO83PH.html', 'Авто в хорошому стані', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/m1wraoyabxp32-UA\\/image;s=644x461\"]', 20566, 'avto_v_horoshomu_stani', 7, NULL, '2022-03-15 18:47:47', NULL, 1),
(8, 7, 13, '743102257', 'https://www.olx.ua/d/obyavlenie/priymu-v-dar-avto-dlya-sohraneniya-IDOhYQh.html', 'Без фото\n                                                                        \n\n                        \n                          \n                    \n\n                        Прийму в дар авто для сохранения', NULL, NULL, 11128, 'bez_foto_priymu_v_dar_avto_dlya_sohraneniya', 8, NULL, '2022-03-15 18:47:47', NULL, 1),
(9, 7, 13, '713487728', 'https://www.olx.ua/d/obyavlenie/avto-toyota-carina-e-IDMhIKA.html', 'Авто Toyota carina e', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/h2sl1kqtg103-UA\\/image;s=644x461\"]', 94018, 'avto_toyota_carina_e', 9, NULL, '2022-03-15 18:47:47', NULL, 1),
(10, 7, 13, '733560517', 'https://www.olx.ua/d/obyavlenie/mercedes-metris-avto-z-ameriki-srochno-IDNDVBf.html', 'Mercedes metris авто з Америки срочно', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/sw9xwpwn2hxq2-UA\\/image;s=644x461\"]', 293806, 'mercedes_metris_avto_z_ameriki_srochno', 10, NULL, '2022-03-15 18:47:47', NULL, 1),
(11, 7, 13, '736597515', 'https://www.olx.ua/d/obyavlenie/prodam-avto-renault-IDNQGF5.html', 'Продам Авто Renault', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/idgzvdnzce3b3-UA\\/image;s=644x461\"]', 149841, 'prodam_avto_renault', 11, NULL, '2022-03-15 18:47:47', NULL, 1),
(12, 7, 13, '743101495', 'https://www.olx.ua/d/obyavlenie/prodayu-avto-vaz-2105-IDOhYDZ.html', 'Продаю авто ВАЗ 2105', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/1wg3ib8ab46k1-UA\\/image;s=644x461\"]', 10283, 'prodayu_avto_vaz_2105', 12, NULL, '2022-03-15 18:47:47', NULL, 1),
(13, 7, 13, '739411690', 'https://www.olx.ua/d/obyavlenie/prodam-vlasne-avto-IDO2uL0.html', 'Продам власне авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ff0c0lit84y41-UA\\/image;s=644x461\"]', 135151, 'prodam_vlasne_avto', 13, NULL, '2022-03-15 18:47:47', NULL, 1),
(14, 7, 13, '737990875', 'https://www.olx.ua/d/obyavlenie/avto-z-nmechchini-IDNVx8D.html', 'Авто з Німеччини', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zbwjf9afcovh2-UA\\/image;s=644x461\"]', 274709, 'avto_z_nimechchini', 14, NULL, '2022-03-15 18:47:47', NULL, 1),
(15, 7, 13, '741281719', 'https://www.olx.ua/d/obyavlenie/prodam-avto-u-chudovomu-stan-prignane-rk-nazad-z-nmechchini-IDOaleL.html', 'Продам  авто у чудовому стані пригнане рік назад з німеччини', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/4z3iy4naldt92-UA\\/image;s=644x461\"]', 161593, 'prodam_avto_u_chudovomu_stani_prignane_rik_nazad_z_nimechchini', 15, NULL, '2022-03-15 18:47:47', NULL, 1),
(16, 7, 13, '733537409', 'https://www.olx.ua/d/obyavlenie/alfa-romeo-164-prodam-legendu-po-tsene-vaz-avto-stoet-vnimaniya-obmen-IDNDQAx.html', 'Alfa romeo 164 продам легенду по цене ваз авто стоет внимания обмен', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ckx2dj51qoqg3-UA\\/image;s=644x461\"]', 41133, 'alfa_romeo_164_prodam_legendu_po_cene_vaz_avto_stoet_vnimaniya_obmen', 16, NULL, '2022-03-15 18:47:47', NULL, 1),
(17, 7, 13, '742888415', 'https://www.olx.ua/d/obyavlenie/prodam-svoe-avto-IDOh5dd.html', 'Продам своё авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/z8bzjf1ms2f43-UA\\/image;s=644x461\"]', 114584, 'prodam_svoe_avto', 17, NULL, '2022-03-15 18:47:47', '2022-03-15 18:47:49', 1),
(18, 7, 13, '621317928', 'https://www.olx.ua/d/obyavlenie/prodam-avto-na-hodu-IDG2ZaU.html', 'Продам авто на ходу', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/tl1gshs082ub3-UA\\/image;s=644x461\"]', 23504, 'prodam_avto_na_hodu', 18, NULL, '2022-03-15 18:47:47', NULL, 1),
(19, 7, 13, '742589624', 'https://www.olx.ua/d/obyavlenie/avto-volkswagen-passat-b3-IDOfPu0.html', 'Авто, Volkswagen passat b3', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/d7l3bbaf2v1d-UA\\/image;s=644x461\"]', 108708, 'avto_volkswagen_passat_b3', 19, NULL, '2022-03-15 18:47:47', NULL, 1),
(20, 7, 13, '742929887', 'https://www.olx.ua/d/obyavlenie/prodam-nerozmitnene-avto-IDOhg07.html', 'Продам нерозмитнене авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/kj98gtq8rmg11-UA\\/image;s=644x461\"]', 73452, 'prodam_nerozmitnene_avto', 20, NULL, '2022-03-15 18:47:47', '2022-03-15 18:47:50', 1),
(21, 7, 13, '742172813', 'https://www.olx.ua/d/obyavlenie/prodam-avto-ideal-2-IDOe53f.html', 'Продам авто ideal 2', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/0jzgett4kpe73-UA\\/image;s=644x461\"]', 79328, 'prodam_avto_ideal_2', 21, NULL, '2022-03-15 18:47:47', NULL, 1),
(22, 7, 13, '736494060', 'https://www.olx.ua/d/obyavlenie/avto-stroen-s4-pkasso-IDNQfKs.html', 'Авто Сітроен С4 Пікассо', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/tb31yk59vsdy2-UA\\/image;s=644x461\"]', 226231, 'avto_sitroen_s4_pikasso', 22, NULL, '2022-03-15 18:47:47', NULL, 1),
(23, 7, 13, '706639941', 'https://www.olx.ua/d/obyavlenie/avto-nissan-juke-IDLOZkp.html', 'Авто Nissan Juke', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/eqicgitczfzn3-UA\\/image;s=644x461\"]', 411299, 'avto_nissan_juke', 23, NULL, '2022-03-15 18:47:47', NULL, 1),
(24, 7, 13, '733862009', 'https://www.olx.ua/d/obyavlenie/prodam-avto-v-norm-stan-IDNFd21.html', 'Продам авто в норм стані', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/x4ljtac9u9zo-UA\\/image;s=644x461\"]', 11000, 'prodam_avto_v_norm_stani', 24, NULL, '2022-03-15 18:47:47', NULL, 1),
(25, 7, 13, '743099213', 'https://www.olx.ua/d/obyavlenie/prodam-ili-obmen-na-avto-pomenshe-IDOhY3b.html', 'Продам  или обмен на авто поменьше', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/b9houauaaet71-UA\\/image;s=644x461\"]', 47009, 'prodam_ili_obmen_na_avto_pomenshe', 25, NULL, '2022-03-15 18:47:47', NULL, 1),
(26, 7, 13, '742133161', 'https://www.olx.ua/d/obyavlenie/avto-svzhoprignane-IDOdUJH.html', 'Авто свіжопригнане', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/fqywvvksc2qp-UA\\/image;s=644x461\"]', 188036, 'avto_svizhoprignane', 26, NULL, '2022-03-15 18:47:47', '2022-03-15 18:47:51', 1),
(27, 7, 13, '712760861', 'https://www.olx.ua/d/obyavlenie/prodam-avto-reno-megan-2-IDMeFEW.html', 'Продам авто Рено Меган 2', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/6319wp8tyg4t-UA\\/image;s=644x461\"]', 142496, 'prodam_avto_reno_megan_2', 27, NULL, '2022-03-15 18:47:47', NULL, 1),
(28, 7, 13, '733488269', 'https://www.olx.ua/d/obyavlenie/prodazha-avto-torez-IDNDDNX.html', 'Продажа авто торез', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/xu9kycxr99gk3-UA\\/image;s=644x461\"]', 64637, 'prodazha_avto_torez', 28, NULL, '2022-03-15 18:47:47', NULL, 1),
(29, 7, 13, '728276001', 'https://www.olx.ua/d/obyavlenie/avto-fort-skorpon-IDNhLR7.html', 'Авто Форт скорпіон', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/a5269vjpc5462-UA\\/image;s=644x461\"]', 23504, 'avto_fort_skorpion', 29, NULL, '2022-03-15 18:47:47', NULL, 1),
(30, 7, 13, '743098575', 'https://www.olx.ua/d/obyavlenie/obmenyayu-ford-scorpio-na-avto-IDOhXST.html', 'Без фото\n                                                                        \n\n                        \n                          \n                    \n\n                        Обменяю Ford Scorpio на авто', NULL, NULL, 0, 'bez_foto_obmenyayu_ford_scorpio_na_avto', 30, NULL, '2022-03-15 18:47:47', NULL, 2),
(31, 7, 13, '743098510', 'https://www.olx.ua/d/obyavlenie/prodayu-avto-renault-IDOhXRQ.html', 'Продаю авто Renault', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/catt2dawziol3-UA\\/image;s=644x461\"]', 155717, 'prodayu_avto_renault', 31, NULL, '2022-03-15 18:47:47', NULL, 1),
(32, 7, 13, '730226484', 'https://www.olx.ua/d/obyavlenie/avto-ford-c-max-2013-hybrid-IDNpXgv.html', 'Авто Ford C-Max 2013 Hybrid', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/57ebq08l231p-UA\\/image;s=644x461\"]', 329063, 'avto_ford_c_max_2013_hybrid', 32, NULL, '2022-03-15 18:47:47', NULL, 1),
(33, 7, 13, '738818714', 'https://www.olx.ua/d/obyavlenie/prodam-obmen-avto-ili-dom-IDO00uS.html', 'Продам обмен авто или дом', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/sue8f2ihs8va3-UA\\/image;s=644x461\"]', 176284, 'prodam_obmen_avto_ili_dom', 33, NULL, '2022-03-15 18:47:47', NULL, 1),
(34, 7, 13, '741198747', 'https://www.olx.ua/d/obyavlenie/mozhliviy-obmin-na-druge-avtoz-moyu-doplatoyu-IDO9ZEw.html', 'Можливий обмин на друге авто\nЗ моєю доплатою', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/41b6bkl866802-UA\\/image;s=644x461\"]', 42602, 'mozhliviy_obmin_na_druge_avto_z_moieyu_doplatoyu', 34, NULL, '2022-03-15 18:47:47', NULL, 1),
(35, 7, 13, '741585883', 'https://www.olx.ua/d/obyavlenie/prodam-byudzhetne-ta-ekonomne-avto-IDObCmD.html', 'Продам бюджетне та економне авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/iw3apkgupiwf2-UA\\/image;s=644x461\"]', 26413, 'prodam_byudzhetne_ta_ekonomne_avto', 35, NULL, '2022-03-15 18:47:47', NULL, 1),
(36, 7, 13, '743097848', 'https://www.olx.ua/d/obyavlenie/avto-mashina-avtomobl-golf-2-IDOhXHa.html', 'Авто машина автомобіль гольф 2', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/e91f5k8lz3jf1-UA\\/image;s=644x461\"]', 23504, 'avto_mashina_avtomobil_golf_2', 36, NULL, '2022-03-15 18:47:47', NULL, 1),
(37, 7, 13, '743097745', 'https://www.olx.ua/d/obyavlenie/srochno-prodam-avto-IDOhXFw.html', 'Срочно продам авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/2d8c0kfj02al3-UA\\/image;s=644x461\"]', 164531, 'srochno_prodam_avto', 37, NULL, '2022-03-15 18:47:48', NULL, 1),
(38, 7, 13, '733215698', 'https://www.olx.ua/d/obyavlenie/volkswagen-jetta-se-1-8-tsi-v-ideale-IDNCuTE.html', 'Volkswagen Jetta SE  1.8 TSI в идеале.', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/4znqzqrp8jnk-UA\\/image;s=644x461\"]', 308496, 'volkswagen_jetta_se_1_8_tsi_v_ideale', 38, NULL, '2022-03-15 18:47:48', NULL, 1),
(39, 7, 13, '723129155', 'https://www.olx.ua/d/obyavlenie/prodam-avto-pezho-partner-2000-g-v-IDMVaWt.html', 'продам авто  пежо партнер 2000 г.в', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/g5cw0zcyjj9o-UA\\/image;s=644x461\"]', 82266, 'prodam_avto_pezho_partner_2000_g_v', 39, NULL, '2022-03-15 18:47:48', NULL, 1),
(40, 7, 13, '741675495', 'https://www.olx.ua/d/obyavlenie/prodam-avto-v-otlichnom-sostoyanii-IDObZFZ.html', 'Продам авто в отличном состоянии', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/i0szltw18wwd-UA\\/image;s=644x461\"]', 499470, 'prodam_avto_v_otlichnom_sostoyanii', 40, NULL, '2022-03-15 18:47:48', NULL, 1),
(41, 7, 13, '740206199', 'https://www.olx.ua/d/obyavlenie/prodam-otlichnoe-avto-v-polnoy-komplektatsii-IDO5PrF.html', 'Продам отличное авто в полной комплектации!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/y4x32wq3chjs-UA\\/image;s=644x461\"]', 170407, 'prodam_otlichnoe_avto_v_polnoy_komplektacii', 41, NULL, '2022-03-15 18:47:48', NULL, 1),
(42, 7, 13, '743095013', 'https://www.olx.ua/d/obyavlenie/prodam-avto-lodgy-IDOhVXr.html', 'Продам авто LODGY', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/a6q39ex4y31p3-UA\\/image;s=644x461\"]', 198290, 'prodam_avto_lodgy', 42, NULL, '2022-03-15 18:47:48', NULL, 1),
(43, 7, 13, '725349079', 'https://www.olx.ua/d/obyavlenie/prodam-otlichnyy-avto-IDN5uqH.html', 'Продам отличный авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zat9midc9v0n3-UA\\/image;s=644x461\"]', 245328, 'prodam_otlichnyy_avto', 43, NULL, '2022-03-15 18:47:48', NULL, 1),
(44, 7, 13, '742924974', 'https://www.olx.ua/d/obyavlenie/prodam-avto-termnovo-IDOheIS.html', 'Продам авто терміново!!!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/lc08v2828rul1-UA\\/image;s=644x461\"]', 117522, 'prodam_avto_terminovo', 44, NULL, '2022-03-15 18:47:48', NULL, 1),
(45, 7, 13, '743065563', 'https://www.olx.ua/d/obyavlenie/avto-moto-IDOhPir.html', 'Авто/мото', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/xyl5pspk281v1-UA\\/image;s=644x461\"]', 499470, 'avto_moto', 45, NULL, '2022-03-15 18:47:48', NULL, 1),
(46, 7, 13, '743013707', 'https://www.olx.ua/d/obyavlenie/prodayu-avto-pezho-207sw-IDOhBO3.html', 'Продаю авто пежо 207SW', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/id7n8kl7gf683-UA\\/image;s=644x461\"]', 146874, 'prodayu_avto_pezho_207sw', 46, NULL, '2022-03-15 18:47:48', NULL, 1),
(47, 7, 13, '734065011', 'https://www.olx.ua/d/obyavlenie/avto-kraysler-saratoga-IDNG3Qf.html', 'Авто Крайслер Саратога', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/tp627d6bk6y23-UA\\/image;s=644x461\"]', 41000, 'avto_kraysler_saratoga', 47, NULL, '2022-03-15 18:47:48', NULL, 1),
(48, 7, 13, '742205913', 'https://www.olx.ua/d/obyavlenie/sens-avto-ekon-variant-IDOedF7.html', 'Sens авто экон вариант', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/5id5cr54pov81-UA\\/image;s=644x461\"]', 96956, 'sens_avto_ekon_variant', 48, NULL, '2022-03-15 18:47:48', NULL, 1),
(49, 7, 13, '741852552', 'https://www.olx.ua/d/obyavlenie/prodam-svoy-avto-IDOcJJK.html', 'Продам свой  авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/lph7l737ok741-UA\\/image;s=644x461\"]', 367258, 'prodam_svoy_avto', 49, NULL, '2022-03-15 18:47:48', NULL, 1),
(50, 7, 13, '742864237', 'https://www.olx.ua/d/obyavlenie/prodam-avto-mazda-3-IDOgYWf.html', 'Продам авто мазда 3', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zl04lbvgmcok-UA\\/image;s=644x461\"]', 141027, 'prodam_avto_mazda_3', 50, NULL, '2022-03-15 18:47:48', NULL, 1),
(51, 7, 13, '728718894', 'https://www.olx.ua/d/obyavlenie/prodam-avto-ford-fokus-IDNjD4y.html', 'Продам авто Форд фокус', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/aohwkxac2all-UA\\/image;s=644x461\"]', 190680, 'prodam_avto_ford_fokus', 51, NULL, '2022-03-15 18:47:48', NULL, 1),
(52, 7, 13, '743093854', 'https://www.olx.ua/d/obyavlenie/srochno-prodam-avto-IDOhVEK.html', 'Срочно продам авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/r68sf4m3wdj63-UA\\/image;s=644x461\"]', 39664, 'srochno_prodam_avto', 52, NULL, '2022-03-15 18:47:48', NULL, 1),
(53, 7, 13, '743093391', 'https://www.olx.ua/d/obyavlenie/avto-z-nmetchini-IDOhVxh.html', 'Авто з німетчини', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/h5dd6pm71lup3-UA\\/image;s=644x461\"]', 152779, 'avto_z_nimetchini', 53, NULL, '2022-03-15 18:47:48', NULL, 1),
(54, 7, 13, '738374317', 'https://www.olx.ua/d/obyavlenie/avto-niva-shevrole-IDNY8Tb.html', 'Авто, нива шевроле', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ghc0g2330w2k1-UA\\/image;s=644x461\"]', 132213, 'avto_niva_shevrole', 54, NULL, '2022-03-15 18:47:48', NULL, 1),
(55, 7, 13, '743093194', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDOhVu6.html', 'Продам Авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/sp30d8jdecmy2-UA\\/image;s=644x461\"]', 102832, 'prodam_avto', 55, NULL, '2022-03-15 18:47:48', NULL, 1),
(56, 7, 13, '729467648', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vaz-2109-2011-g-v-IDNmLRe.html', 'Продам авто ВАЗ 2109, 2011 г.в.', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/2x7dey4tx4bu2-UA\\/image;s=644x461\"]', 73452, 'prodam_avto_vaz_2109_2011_g_v', 56, NULL, '2022-03-15 18:47:48', NULL, 1),
(57, 7, 13, '741230757', 'https://www.olx.ua/d/obyavlenie/prodam-avto-zaz-slavuta-2003-1-2-karbyurator-benzin-120000-probeg-999-IDOa7YN.html', 'Продам авто ЗАЗ Славута 2003 1,2 карбюратор бензин 120000 пробег 999 $', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/vn2lv46udmhx1-UA\\/image;s=644x461\"]', 29351, 'prodam_avto_zaz_slavuta_2003_1_2_karbyurator_benzin_120000_probeg_999', 57, NULL, '2022-03-15 18:47:48', NULL, 1),
(58, 7, 13, '737879111', 'https://www.olx.ua/d/obyavlenie/avto-lexus-rx-330-2004-IDNV43Z.html', 'Авто Lexus RX 330 2004', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zw7i3ipx05ge1-UA\\/image;s=644x461\"]', 317310, 'avto_lexus_rx_330_2004', 58, NULL, '2022-03-15 18:47:48', NULL, 1),
(59, 7, 13, '738143000', 'https://www.olx.ua/d/obyavlenie/avto-lexus-rx-350-2014-IDNXaIg.html', 'Авто Lexus RX 350 2014', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ibo9ogn39d3d1-UA\\/image;s=644x461\"]', 878480, 'avto_lexus_rx_350_2014', 59, NULL, '2022-03-15 18:47:48', NULL, 1),
(60, 7, 13, '738145321', 'https://www.olx.ua/d/obyavlenie/avto-tesla-model-s-85d-2016-IDNXbjH.html', 'Авто Tesla Model S 85D 2016', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zbo1hntizp5z1-UA\\/image;s=644x461\"]', 1231050, 'avto_tesla_model_s_85d_2016', 60, NULL, '2022-03-15 18:47:48', NULL, 1),
(61, 7, 13, '729789598', 'https://www.olx.ua/d/obyavlenie/avto-mercedes-benz-viano-2005-IDNo7BY.html', 'Авто Mercedes-Benz Viano 2005', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/a5lq58omwp4z2-UA\\/image;s=644x461\"]', 320249, 'avto_mercedes_benz_viano_2005', 61, NULL, '2022-03-15 18:47:48', NULL, 1),
(62, 7, 13, '738181140', 'https://www.olx.ua/d/obyavlenie/avto-subaru-impreza-2014-IDNXkDq.html', 'Авто Subaru Impreza 2014', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ofsuywdfjxqf2-UA\\/image;s=644x461\"]', 305558, 'avto_subaru_impreza_2014', 62, NULL, '2022-03-15 18:47:48', NULL, 1),
(63, 7, 13, '708874751', 'https://www.olx.ua/d/obyavlenie/avto-chevrolet-malibu-lt-2016-IDLYmHJ.html', 'Авто Chevrolet Malibu LT 2016', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/9zuqkg54x5ti-UA\\/image;s=644x461\"]', 384886, 'avto_chevrolet_malibu_lt_2016', 63, NULL, '2022-03-15 18:47:48', NULL, 1),
(64, 7, 13, '742841130', 'https://www.olx.ua/d/obyavlenie/bmw-x5-e70-3-0d-bmv-h5-e70-avto-IDOgSUy.html', 'BMW X5 E70 3.0D БМВ Х5 Е70 авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/5np4qvbeg8z51-UA\\/image;s=644x461\"]', 396638, 'bmw_x5_e70_3_0d_bmv_h5_e70_avto', 64, NULL, '2022-03-15 18:47:48', NULL, 1),
(65, 7, 13, '743092244', 'https://www.olx.ua/d/obyavlenie/prodam-avto-na-hodu-IDOhVeM.html', 'Продам  авто на ходу', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/h9p2tb8083np2-UA\\/image;s=644x461\"]', 40545, 'prodam_avto_na_hodu', 65, NULL, '2022-03-15 18:47:48', NULL, 1),
(66, 7, 13, '736992002', 'https://www.olx.ua/d/obyavlenie/prodam-avto-marki-zhigul-IDNSlhM.html', 'Продам авто марки Жигулі', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/uif0qnbt02ar-UA\\/image;s=644x461\"]', 14000, 'prodam_avto_marki_zhiguli', 66, NULL, '2022-03-15 18:47:48', NULL, 1),
(67, 7, 13, '742539236', 'https://www.olx.ua/d/obyavlenie/land-rover-sport-2-7-IDOfCni.html', 'Land Rover Sport 2.7', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/7wlkjk2cmw262-UA\\/image;s=644x461\"]', 205635, 'land_rover_sport_2_7', 67, NULL, '2022-03-15 18:47:48', NULL, 1),
(68, 7, 13, '714336790', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDMlhD8.html', 'Продам авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/bfx2np1slk8n1-UA\\/image;s=644x461\"]', 543541, 'prodam_avto', 68, NULL, '2022-03-15 18:47:48', NULL, 1),
(69, 7, 13, '742547282', 'https://www.olx.ua/d/obyavlenie/dacia-logan-dacia-mcv-1-5-dci-75-ambiance-5d-IDOfEt4.html', 'Dacia Logan Dacia MCV 1.5 dCi 75 Ambiance 5d', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/jfdyg7t2ephq1-UA\\/image;s=644x461\"]', 151078, 'dacia_logan_dacia_mcv_1_5_dci_75_ambiance_5d', 69, NULL, '2022-03-15 18:47:49', NULL, 1),
(70, 7, 13, '728690004', 'https://www.olx.ua/d/obyavlenie/prodam-avto-pezho-IDNjwyA.html', 'Продам авто Пежо', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/1h3qii01od252-UA\\/image;s=644x461\"]', 91080, 'prodam_avto_pezho', 70, NULL, '2022-03-15 18:47:49', NULL, 1),
(71, 7, 13, '743029264', 'https://www.olx.ua/d/obyavlenie/avto-ford-sierra-2-0-benz-1988-IDOhFQY.html', 'Авто Ford Sierra 2.0 benz 1988', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ugx3je0xz27j-UA\\/image;s=644x461\"]', 19685, 'avto_ford_sierra_2_0_benz_1988', 71, NULL, '2022-03-15 18:47:49', NULL, 1),
(72, 7, 13, '703970686', 'https://www.olx.ua/d/obyavlenie/prodam-avto-reno-11-IDLDMWU.html', 'Продам авто рено 11', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/hygde5w7kcqi2-UA\\/image;s=644x461\"]', 17628, 'prodam_avto_reno_11', 72, NULL, '2022-03-15 18:47:49', NULL, 1),
(73, 7, 13, '743090421', 'https://www.olx.ua/d/obyavlenie/prodam-avto-folksvagen-passat-IDOhWLn.html', 'Продам авто фольксваген пассат', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/if0pr3ln36452-UA\\/image;s=644x461\"]', 173346, 'prodam_avto_folksvagen_passat', 73, NULL, '2022-03-15 18:47:49', NULL, 1),
(74, 7, 13, '742543512', 'https://www.olx.ua/d/obyavlenie/audi-a6-2017-premium-plus-IDOfDug.html', 'Audi A6 2017 Prеmium Plus', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/kbasgp624eg8-UA\\/image;s=644x461\"]', 734515, 'audi_a6_2017_premium_plus', 74, NULL, '2022-03-15 18:47:49', NULL, 1),
(75, 7, 13, '743089862', 'https://www.olx.ua/d/obyavlenie/avto-opel-askona-IDOhWCm.html', 'Авто Опель Аскона', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/96ju3svxzhac3-UA\\/image;s=644x461\"]', 35257, 'avto_opel_askona', 75, NULL, '2022-03-15 18:47:49', NULL, 1),
(76, 7, 13, '743089755', 'https://www.olx.ua/d/obyavlenie/prodam-avto-cheri-amulet-ne-dorogo-IDOhWAD.html', 'Продам авто Чери Амулет .не дорого', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/qweeswl18dr1-UA\\/image;s=644x461\"]', 73452, 'prodam_avto_cheri_amulet_ne_dorogo', 76, NULL, '2022-03-15 18:47:49', NULL, 1),
(77, 7, 13, '720123003', 'https://www.olx.ua/d/obyavlenie/prodayu-avto-mitsubishi-lanser-2011-IDMJyT9.html', 'Продаю авто Mitsubishi Lanser 2011.', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/hd30x2iimi9z1-UA\\/image;s=644x461\"]', 202726, 'prodayu_avto_mitsubishi_lanser_2011', 77, NULL, '2022-03-15 18:47:49', NULL, 1),
(78, 7, 13, '740500695', 'https://www.olx.ua/d/obyavlenie/prodam-avto-mitsubishi-mirage-IDO743B.html', 'Продам авто   Mitsubishi Mirage', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/qlx6qg2qvfpu3-UA\\/image;s=644x461\"]', 249735, 'prodam_avto_mitsubishi_mirage', 78, NULL, '2022-03-15 18:47:49', NULL, 1),
(79, 7, 13, '732576376', 'https://www.olx.ua/d/obyavlenie/avto-shevrole-aveo-1-5-benzin-2011god-obmenrassrochka-vznos-ot-25-IDNzOA0.html', 'Авто Шевроле Авео 1.5 бензин 2011год обмен[Рассрочка, взнос от 25%]', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/stwa9ixpcngf1-UA\\/image;s=644x461\"]', 155717, 'avto_shevrole_aveo_1_5_benzin_2011god_obmen_rassrochka_vznos_ot_25', 79, NULL, '2022-03-15 18:47:49', NULL, 1),
(80, 7, 13, '743089333', 'https://www.olx.ua/d/obyavlenie/avto-na-povnomu-hodu-sv-poyhav-zvernt-rozkazhu-podrobno-obmn-tezh-ts-IDOhWtP.html', 'Авто на повному ходу сів пойхав зверніть розкажу подробно обмін теж ці', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zz25p7mm62gg-UA\\/image;s=644x461\"]', 17628, 'avto_na_povnomu_hodu_siv_poyhav_zvernit_rozkazhu_podrobno_obmin_tezh_ci', 80, NULL, '2022-03-15 18:47:49', NULL, 1),
(81, 7, 13, '743089094', 'https://www.olx.ua/d/obyavlenie/mitsubishi-lancer-x-mittsubisi-lantser-10-legkovoe-avto-gaz-benzin-IDOhWpY.html', 'Mitsubishi Lancer X, Митцубиси Ланцер 10, легковое авто,  газ-бензин', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/vhyb8860wdmb-UA\\/image;s=644x461\"]', 190974, 'mitsubishi_lancer_x_mitcubisi_lancer_10_legkovoe_avto_gaz_benzin', 81, NULL, '2022-03-15 18:47:49', NULL, 1),
(82, 7, 13, '731511894', 'https://www.olx.ua/d/obyavlenie/avto-na-prodazh-obmn-IDNwlEV.html', 'Авто на продаж, обмін', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/flbwh88ahim33-UA\\/image;s=644x461\"]', 29381, 'avto_na_prodazh_obmin', 82, NULL, '2022-03-15 18:47:49', NULL, 1),
(83, 7, 13, '743088638', 'https://www.olx.ua/d/obyavlenie/prodayu-avto-otlichnoe-opel-astra-sports-tourer-125-IDOhWiC.html', 'Продаю авто! Отличное Opel Astra Sports Tourer 125', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/zctpw3vlt0hj2-UA\\/image;s=644x461\"]', 202697, 'prodayu_avto_otlichnoe_opel_astra_sports_tourer_125', 83, NULL, '2022-03-15 18:47:49', NULL, 1),
(84, 7, 13, '742535170', 'https://www.olx.ua/d/obyavlenie/vaz-2101-normalnoe-sostoyanie-IDOfBjI.html', 'Ваз 2101 нормальное состояние', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/juro7z7hehr23-UA\\/image;s=644x461\"]', 14500, 'vaz_2101_normalnoe_sostoyanie', 84, NULL, '2022-03-15 18:47:49', NULL, 1),
(85, 7, 13, '742535091', 'https://www.olx.ua/d/obyavlenie/volvo-v40-2014-5-porte-berlina-d2-geartronic-business-IDOfBir.html', 'Volvo V40  2014 5 Porte Berlina D2 GEARTRONIC BUSINESS', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/c240n8468ncs2-UA\\/image;s=644x461\"]', 366445, 'volvo_v40_2014_5_porte_berlina_d2_geartronic_business', 85, NULL, '2022-03-15 18:47:49', NULL, 1),
(86, 7, 13, '742904152', 'https://www.olx.ua/d/obyavlenie/prodam-avto-mitsubishi-IDOh9j2.html', 'Продам авто mitsubishi', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/kmen4b4j7pdo3-UA\\/image;s=644x461\"]', 163062, 'prodam_avto_mitsubishi', 86, NULL, '2022-03-15 18:47:49', NULL, 1),
(87, 7, 13, '742577698', 'https://www.olx.ua/d/obyavlenie/zx-avto-adminiral-IDOfMnE.html', 'ZX Avto Adminiral', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/5nz8aaz8quk03-UA\\/image;s=644x461\"]', 117522, 'zx_avto_adminiral', 87, NULL, '2022-03-15 18:47:49', NULL, 1),
(88, 7, 13, '743086943', 'https://www.olx.ua/d/obyavlenie/boevaya-shesterka-1-3-na-hodu-dvizhok-korobka-ideal-avto-vaz-2106-srochno-IDOhURh.html', 'Боевая шестёрка 1.3 на ходу. Движок,коробка-идеал.Авто ваз 2106,Срочно', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/q3ngr7eoucgh1-UA\\/image;s=644x461\"]', 14700, 'boevaya_shesterka_1_3_na_hodu_dvizhok_korobka_ideal_avto_vaz_2106_srochno', 88, NULL, '2022-03-15 18:47:49', NULL, 1),
(89, 7, 13, '743056187', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vaz-2115-IDOhMRd.html', 'Продам авто ВАЗ 2115', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/l6a089m08jgc3-UA\\/image;s=644x461\"]', 51416, 'prodam_avto_vaz_2115', 89, NULL, '2022-03-15 18:47:49', NULL, 1),
(90, 7, 13, '732857112', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vaz-2106-IDNAZC0.html', 'Продам авто ВАЗ 2106', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/r2a94eyuufr03-UA\\/image;s=644x461\"]', 12000, 'prodam_avto_vaz_2106', 90, NULL, '2022-03-15 18:47:49', NULL, 1),
(91, 7, 13, '742804434', 'https://www.olx.ua/d/obyavlenie/prodam-avto-v-rabochem-sostoyanii-IDOgJmG.html', 'Продам авто в рабочем состоянии', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/f0ooejxpp93k2-UA\\/image;s=644x461\"]', 99894, 'prodam_avto_v_rabochem_sostoyanii', 91, NULL, '2022-03-15 18:47:49', '2022-03-15 18:47:51', 1),
(92, 7, 13, '729922613', 'https://www.olx.ua/d/obyavlenie/avto-chevrolet-equinox-2013-IDNoGdn.html', 'Авто Chevrolet Equinox 2013', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/yclp4gisu2pn2-UA\\/image;s=644x461\"]', 323187, 'avto_chevrolet_equinox_2013', 92, NULL, '2022-03-15 18:47:49', NULL, 1),
(93, 7, 13, '721020285', 'https://www.olx.ua/d/obyavlenie/reno-19-prodam-avto-obmen-IDMNkjr.html', 'Рено 19 продам авто Обмен', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/k8a12jnu54ju2-UA\\/image;s=644x461\"]', 44042, 'reno_19_prodam_avto_obmen', 93, NULL, '2022-03-15 18:47:49', NULL, 1),
(94, 7, 13, '742530909', 'https://www.olx.ua/d/obyavlenie/honda-cr-v-2-0-l-benzin-IDOfAcZ.html', 'Honda CR-V, 2.0 l / Бензин', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/g5kwbtz8xyqf-UA\\/image;s=644x461\"]', 295728, 'honda_cr_v_2_0_l_benzin', 94, NULL, '2022-03-15 18:47:49', NULL, 1),
(95, 7, 13, '743087536', 'https://www.olx.ua/d/obyavlenie/prodam-avto-renault-IDOhW0Q.html', 'Продам авто Renault', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/uwkirxtttkbk3-UA\\/image;s=644x461\"]', 267363, 'prodam_avto_renault', 95, NULL, '2022-03-15 18:47:49', NULL, 1),
(96, 7, 13, '742530311', 'https://www.olx.ua/d/obyavlenie/toyota-rav4-2-2-l-2008-IDOfA3l.html', 'Toyota RAV4, 2.2 l / 2008', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/xvyjj4mpn1cv2-UA\\/image;s=644x461\"]', 276441, 'toyota_rav4_2_2_l_2008', 96, NULL, '2022-03-15 18:47:49', NULL, 1),
(97, 7, 13, '725900114', 'https://www.olx.ua/d/obyavlenie/prodam-avto-lada-kalina-IDN7NMm.html', 'Продам авто Лада Калина', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/nrv58h740lt1-UA\\/image;s=644x461\"]', 85204, 'prodam_avto_lada_kalina', 97, NULL, '2022-03-15 18:47:49', NULL, 1),
(98, 7, 13, '743086629', 'https://www.olx.ua/d/obyavlenie/prodam-avto-wv-lupo-IDOhUMd.html', 'Продам авто wv lupo', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/4j7idkdl6tiu1-UA\\/image;s=644x461\"]', 19097, 'prodam_avto_wv_lupo', 98, NULL, '2022-03-15 18:47:49', NULL, 1),
(99, 7, 13, '742525227', 'https://www.olx.ua/d/obyavlenie/mitsubishi-lancer-1-8-l-2008-IDOfyJl.html', 'Mitsubishi Lancer, 1.8 l / 2008', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/na49j5dv3udf1-UA\\/image;s=644x461\"]', 192866, 'mitsubishi_lancer_1_8_l_2008', 99, NULL, '2022-03-15 18:47:49', NULL, 1),
(100, 7, 13, '742524170', 'https://www.olx.ua/d/obyavlenie/toyota-corolla-1-6-l-2007-IDOfysi.html', 'Toyota Corolla, 1.6 l / 2007', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/mkpimajhhi3n3-UA\\/image;s=644x461\"]', 170365, 'toyota_corolla_1_6_l_2007', 100, NULL, '2022-03-15 18:47:49', NULL, 1),
(101, 7, 13, '743086091', 'https://www.olx.ua/d/obyavlenie/avto-vaz-zhiguli-IDOhUDx.html', 'Без фото\n                                                                        \n\n                        \n                          \n                    \n\n                        Авто Ваз жигули!!!', NULL, NULL, 10000, 'bez_foto_avto_vaz_zhiguli', 101, NULL, '2022-03-15 18:47:49', NULL, 1),
(102, 7, 13, '741521083', 'https://www.olx.ua/d/obyavlenie/prodam-avto-reno-laguna2-IDOblwt.html', 'Продам авто Рено лагуна2', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/6r40fes55hk02-UA\\/image;s=644x461\"]', 145434, 'prodam_avto_reno_laguna2', 102, NULL, '2022-03-15 18:47:50', NULL, 1),
(103, 7, 13, '741555609', 'https://www.olx.ua/d/obyavlenie/avto-dodzh-kraysler-IDObuul.html', 'Авто Додж крайслер', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/cmn300n169pi2-UA\\/image;s=644x461\"]', 73452, 'avto_dodzh_kraysler', 103, NULL, '2022-03-15 18:47:50', NULL, 1),
(104, 7, 13, '735065791', 'https://www.olx.ua/d/obyavlenie/prodam-abo-obmnyayu-moskvich-408412-na-yakes-nshe-avto-IDNKgbR.html', 'Продам або обміняю москвич 408(412) на якесь інше авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/k0hwy2utyiiq2-UA\\/image;s=644x461\"]', 12000, 'prodam_abo_obminyayu_moskvich_408_412_na_yakes_inshe_avto', 104, NULL, '2022-03-15 18:47:50', NULL, 1),
(105, 7, 13, '742519059', 'https://www.olx.ua/d/obyavlenie/nissan-qashqai-1-6-l-2012-IDOfx7R.html', 'Nissan Qashqai, 1.6 l / 2012', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ohx0ivc6z3ws2-UA\\/image;s=644x461\"]', 318229, 'nissan_qashqai_1_6_l_2012', 105, NULL, '2022-03-15 18:47:50', NULL, 1),
(106, 7, 13, '736706192', 'https://www.olx.ua/d/obyavlenie/avto-fiat-punto-fiat-punto-IDNR8WV.html', 'Авто Fiat Punto Фиат Пунто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/mgkofy8bgyai3-UA\\/image;s=644x461\"]', 52885, 'avto_fiat_punto_fiat_punto', 106, NULL, '2022-03-15 18:47:50', NULL, 1),
(107, 7, 13, '742518041', 'https://www.olx.ua/d/obyavlenie/ford-galaxy-1-8-l-2007-IDOfvRr.html', 'Ford Galaxy, 1.8 l / 2007', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/fcccgxryy2b5-UA\\/image;s=644x461\"]', 212153, 'ford_galaxy_1_8_l_2007', 107, NULL, '2022-03-15 18:47:50', NULL, 1),
(108, 7, 13, '742517148', 'https://www.olx.ua/d/obyavlenie/renault-scenic-1-2-tce-collection-IDOfvD2.html', 'Renault Scenic 1.2 TCe Collection', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/v4qzcm1y0yjo2-UA\\/image;s=644x461\"]', 327872, 'renault_scenic_1_2_tce_collection', 108, NULL, '2022-03-15 18:47:50', NULL, 1),
(109, 7, 13, '736969688', 'https://www.olx.ua/d/obyavlenie/prodam-avto-avd-80-v4-kuzov-gaz-benzin-2-0-kuba-1992-roku-IDNSftS.html', 'Продам авто авді 80 в4 кузов газ бензин 2.0 куба 1992 року', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/no9h3wshs97d1-UA\\/image;s=644x461\"]', 105770, 'prodam_avto_avdi_80_v4_kuzov_gaz_benzin_2_0_kuba_1992_roku', 109, NULL, '2022-03-15 18:47:50', NULL, 1),
(110, 7, 13, '742514288', 'https://www.olx.ua/d/obyavlenie/ford-focus-1-0-l-2016-benzin-IDOfwSU.html', 'Ford Focus, 1.0 l / 2016 / Бензин', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/98zmydwqbj1a1-UA\\/image;s=644x461\"]', 305371, 'ford_focus_1_0_l_2016_benzin', 110, NULL, '2022-03-15 18:47:50', NULL, 1),
(111, 7, 13, '743084729', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDOhUhz.html', 'Продам авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/equi5nnicxxp3-UA\\/image;s=644x461\"]', 167469, 'prodam_avto', 111, NULL, '2022-03-15 18:47:50', NULL, 1),
(112, 7, 13, '742513560', 'https://www.olx.ua/d/obyavlenie/mazda-6-1-8-l-2008-IDOfwHa.html', 'Mazda 6, 1.8 l / 2008', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/0etwqduyzwlm-UA\\/image;s=644x461\"]', 196080, 'mazda_6_1_8_l_2008', 112, NULL, '2022-03-15 18:47:50', NULL, 1),
(113, 7, 13, '742512937', 'https://www.olx.ua/d/obyavlenie/mini-clubman-1-6-l-2008-benzin-IDOfwx7.html', 'Mini Clubman, 1.6 l / 2008 / Бензин', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/o44rn7uwtqg13-UA\\/image;s=644x461\"]', 215367, 'mini_clubman_1_6_l_2008_benzin', 113, NULL, '2022-03-15 18:47:50', NULL, 1),
(114, 7, 13, '742512314', 'https://www.olx.ua/d/obyavlenie/skoda-yeti-2-0-l-2009-IDOfwn4.html', 'Skoda Yeti, 2.0 l / 2009', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ocoojkf8sbza-UA\\/image;s=644x461\"]', 270012, 'skoda_yeti_2_0_l_2009', 114, NULL, '2022-03-15 18:47:50', NULL, 1),
(115, 7, 13, '704619737', 'https://www.olx.ua/d/obyavlenie/prodam-avto-a6s4-kvatro-IDLGwMt.html', 'Продам авто А6С4 кватро', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/75c3zupjahr81-UA\\/image;s=644x461\"]', 148372, 'prodam_avto_a6s4_kvatro', 115, NULL, '2022-03-15 18:47:50', NULL, 1),
(116, 7, 13, '742025636', 'https://www.olx.ua/d/obyavlenie/prodam-avto-mazda-5-IDOdsLq.html', 'Продам авто Мазда 5', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/scbu3a1blb8z2-UA\\/image;s=644x461\"]', 176284, 'prodam_avto_mazda_5', 116, NULL, '2022-03-15 18:47:50', NULL, 1),
(117, 7, 13, '742511225', 'https://www.olx.ua/d/obyavlenie/volkswagen-golf-1-6-l-2010-IDOfw5w.html', 'Volkswagen Golf, 1.6 l / 2010', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/uh9txoenojxs1-UA\\/image;s=644x461\"]', 192866, 'volkswagen_golf_1_6_l_2010', 117, NULL, '2022-03-15 18:47:50', NULL, 1),
(118, 7, 13, '742510616', 'https://www.olx.ua/d/obyavlenie/audi-a1-1-2-l-2011-IDOfuWG.html', 'Audi A1, 1.2 l / 2011', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/8zf8us20s5dr3-UA\\/image;s=644x461\"]', 247511, 'audi_a1_1_2_l_2011', 118, NULL, '2022-03-15 18:47:50', NULL, 1),
(119, 7, 13, '728488897', 'https://www.olx.ua/d/obyavlenie/avto-nisan-pemerar10-IDNiFeW.html', 'Авто нисан пемерар10', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/le01p6bwlpti-UA\\/image;s=644x461\"]', 55823, 'avto_nisan_pemerar10', 119, NULL, '2022-03-15 18:47:50', NULL, 1),
(120, 7, 13, '741198772', 'https://www.olx.ua/d/obyavlenie/prodam-abo-obmnyayu-horoshe-avto-IDO9ZEU.html', 'Продам або обміняю  хороше авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/tbnhou9trsu72-UA\\/image;s=644x461\"]', 32144, 'prodam_abo_obminyayu_horoshe_avto', 120, NULL, '2022-03-15 18:47:50', NULL, 1),
(121, 7, 13, '741220546', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDOa5k6.html', 'Продам Авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/mxf932dlfd461-UA\\/image;s=644x461\"]', 127806, 'prodam_avto', 121, NULL, '2022-03-15 18:47:50', NULL, 1),
(122, 7, 13, '742505635', 'https://www.olx.ua/d/obyavlenie/peugeot-508-1-6-l-2017-IDOftDl.html', 'Peugeot 508, 1.6 l / 2017', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/hylk4i1gon9d2-UA\\/image;s=644x461\"]', 337516, 'peugeot_508_1_6_l_2017', 122, NULL, '2022-03-15 18:47:50', NULL, 1),
(123, 7, 13, '743083431', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDOhTVD.html', 'Продам Авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/bk1pp6389k0l3-UA\\/image;s=644x461\"]', 16159, 'prodam_avto', 123, NULL, '2022-03-15 18:47:50', NULL, 1),
(124, 7, 13, '742504570', 'https://www.olx.ua/d/obyavlenie/honda-civic-1-3-l-2007-IDOftma.html', 'Honda Civic, 1.3 l / 2007', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/j6ie6ijlbn2n1-UA\\/image;s=644x461\"]', 170365, 'honda_civic_1_3_l_2007', 124, NULL, '2022-03-15 18:47:50', NULL, 1),
(125, 7, 13, '741216814', 'https://www.olx.ua/d/obyavlenie/prodam-avto-v-garnomu-stan-vaz-2107-1998-r-v-IDOa4lU.html', 'Продам авто в гарному стані Ваз 2107 1998 р.в.', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/4k3c1oiool2n-UA\\/image;s=644x461\"]', 42602, 'prodam_avto_v_garnomu_stani_vaz_2107_1998_r_v', 125, NULL, '2022-03-15 18:47:50', NULL, 1),
(126, 7, 13, '742504090', 'https://www.olx.ua/d/obyavlenie/bmw-x1-2-0-l-2011-IDOfteq.html', 'BMW X1, 2.0 l / 2011', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/rwjui6v33lnh3-UA\\/image;s=644x461\"]', 353588, 'bmw_x1_2_0_l_2011', 126, NULL, '2022-03-15 18:47:50', NULL, 1),
(127, 7, 13, '732396541', 'https://www.olx.ua/d/obyavlenie/prodazha-avto-IDNz3Nr.html', 'Продажа авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/svbduo4nytpa2-UA\\/image;s=644x461\"]', 998940, 'prodazha_avto', 127, NULL, '2022-03-15 18:47:50', NULL, 1),
(128, 7, 13, '742503742', 'https://www.olx.ua/d/obyavlenie/citroen-berlingo-IDOft8O.html', 'Citroen Berlingo', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/t5qfy3c0nl71-UA\\/image;s=644x461\"]', 594670, 'citroen_berlingo', 128, NULL, '2022-03-15 18:47:50', NULL, 1),
(129, 7, 13, '741559037', 'https://www.olx.ua/d/obyavlenie/prodam-horoshe-avto-vaz-2109-IDObwnD.html', 'Продам хороше авто ВАЗ 2109', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/afk17tbusgnh2-UA\\/image;s=644x461\"]', 32319, 'prodam_horoshe_avto_vaz_2109', 129, NULL, '2022-03-15 18:47:50', NULL, 1),
(130, 7, 13, '737492728', 'https://www.olx.ua/d/obyavlenie/prodam-avto-mitsubisi-IDNUry0.html', 'Продам авто Митсубиси', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/l011rk9r6h7r1-UA\\/image;s=644x461\"]', 249735, 'prodam_avto_mitsubisi', 130, NULL, '2022-03-15 18:47:50', '2022-03-15 18:47:51', 1),
(131, 7, 13, '743059587', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vaz2106-IDOhNK3.html', 'Продам Авто Ваз2106', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/0d7oxm6ms7ou1-UA\\/image;s=644x461\"]', 36726, 'prodam_avto_vaz2106', 131, NULL, '2022-03-15 18:47:50', NULL, 1),
(132, 7, 13, '742307648', 'https://www.olx.ua/d/obyavlenie/prodazha-svoego-avto-k-prodazhe-ne-gotovilas-IDOeE80.html', 'Продажа своего авто, к продаже не готовилась!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/qjk4wr4qgkp3-UA\\/image;s=644x461\"]', 170407, 'prodazha_svoego_avto_k_prodazhe_ne_gotovilas', 132, NULL, '2022-03-15 18:47:50', NULL, 1),
(133, 7, 13, '742151222', 'https://www.olx.ua/d/obyavlenie/prodam-avto-mazda-IDOdZr0.html', 'Продам Авто Мазда', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/9f4yuasp9smy2-UA\\/image;s=644x461\"]', 27912, 'prodam_avto_mazda', 133, NULL, '2022-03-15 18:47:50', NULL, 1),
(134, 7, 13, '742503562', 'https://www.olx.ua/d/obyavlenie/skoda-fabia-1-4-l-2008-IDOft5U.html', 'Skoda Fabia, 1.4 l / 2008', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/2q9j5r93ivdt-UA\\/image;s=644x461\"]', 151078, 'skoda_fabia_1_4_l_2008', 134, NULL, '2022-03-15 18:47:51', NULL, 1),
(135, 7, 13, '743083019', 'https://www.olx.ua/d/obyavlenie/avto-daewoo-lanos-IDOhTPZ.html', 'Авто Daewoo Lanos', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/kljr92jb7owv2-UA\\/image;s=644x461\"]', 58761, 'avto_daewoo_lanos', 135, NULL, '2022-03-15 18:47:51', NULL, 1),
(136, 7, 13, '716395936', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDMtWja.html', 'Продам Авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/v8l9rlzktkt63-UA\\/image;s=644x461\"]', 378980, 'prodam_avto', 136, NULL, '2022-03-15 18:47:51', NULL, 1),
(137, 7, 13, '742129024', 'https://www.olx.ua/d/obyavlenie/prodam-avto-zaz-1102-IDOdTEY.html', 'Продам авто Заз 1102', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/fx1sdue8wdty1-UA\\/image;s=644x461\"]', 23504, 'prodam_avto_zaz_1102', 137, NULL, '2022-03-15 18:47:51', NULL, 1),
(138, 7, 13, '741350155', 'https://www.olx.ua/d/obyavlenie/prodam-horoshe-avto-IDOaD2z.html', 'Продам хороше авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/loo0ka16x98u1-UA\\/image;s=644x461\"]', 290868, 'prodam_horoshe_avto', 138, NULL, '2022-03-15 18:47:51', NULL, 1),
(139, 7, 13, '742501042', 'https://www.olx.ua/d/obyavlenie/volkswagen-touran-1-4-l-mkpp-benzin-IDOfsrg.html', 'Volkswagen Touran, 1.4 l / МКПП / Бензин', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/3y921ee8x0ac-UA\\/image;s=644x461\"]', 180008, 'volkswagen_touran_1_4_l_mkpp_benzin', 139, NULL, '2022-03-15 18:47:51', NULL, 1),
(140, 7, 13, '742500483', 'https://www.olx.ua/d/obyavlenie/honda-cr-v-2-0-l-2007-IDOfsif.html', 'Honda CR-V, 2.0 l / 2007', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/p17w65u7ebpo3-UA\\/image;s=644x461\"]', 308586, 'honda_cr_v_2_0_l_2007', 140, NULL, '2022-03-15 18:47:51', NULL, 1),
(141, 7, 13, '742499933', 'https://www.olx.ua/d/obyavlenie/mercedes-benz-c220-2-2-l-2010-IDOfs9n.html', 'Mercedes-Benz C220, 2.2 l / 2010', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/kj60who7x6zv3-UA\\/image;s=644x461\"]', 212153, 'mercedes_benz_c220_2_2_l_2010', 141, NULL, '2022-03-15 18:47:51', NULL, 1),
(142, 7, 13, '742499205', 'https://www.olx.ua/d/obyavlenie/citroen-c4-1-6-l-2009-IDOfrXD.html', 'Citroen C4, 1.6 l / 2009', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/gd69mgin1ado2-UA\\/image;s=644x461\"]', 199295, 'citroen_c4_1_6_l_2009', 142, NULL, '2022-03-15 18:47:51', NULL, 1),
(143, 7, 13, '743081523', 'https://www.olx.ua/d/obyavlenie/prodam-avto-IDOhTrR.html', 'Продам авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ol1stk9w557g1-UA\\/image;s=644x461\"]', 235045, 'prodam_avto', 143, NULL, '2022-03-15 18:47:51', NULL, 1),
(144, 7, 13, '742494718', 'https://www.olx.ua/d/obyavlenie/acura-mdx-2013-avto-z-ssha-IDOfqNg.html', 'ACURA MDX 2013 | Авто з США', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/kc47zjru7m8w2-UA\\/image;s=644x461\"]', 531789, 'acura_mdx_2013_avto_z_ssha', 144, NULL, '2022-03-15 18:47:51', NULL, 1),
(145, 7, 13, '692084596', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vw-jetta-1-8-se-IDKPUOM.html', 'Продам авто  VW Jetta 1,8 SE', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/tnw6vpdkkjpl2-UA\\/image;s=644x461\"]', 246797, 'prodam_avto_vw_jetta_1_8_se', 145, NULL, '2022-03-15 18:47:51', NULL, 1),
(146, 7, 13, '727410022', 'https://www.olx.ua/d/obyavlenie/prodam-ili-obmenyayu-avto-na-kvartiru-IDNe8zI.html', 'Продам или обменяю авто на квартиру', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/7f6l8ezvyb95-UA\\/image;s=644x461\"]', 440709, 'prodam_ili_obmenyayu_avto_na_kvartiru', 146, NULL, '2022-03-15 18:47:51', NULL, 1),
(147, 7, 13, '743080067', 'https://www.olx.ua/d/obyavlenie/prodam-mazda-cx-5-grand-turing-IDOhT4n.html', 'Продам Mazda CX-5 Grand Turing', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/r1hpzv5linq72-UA\\/image;s=644x461\"]', 381948, 'prodam_mazda_cx_5_grand_turing', 147, NULL, '2022-03-15 18:47:51', NULL, 1),
(148, 7, 13, '683048513', 'https://www.olx.ua/d/obyavlenie/avto-niva-21214-srochno-IDKe07w.html', 'Авто Нива 21214. Срочно!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/a01yrwclvcuk3-UA\\/image;s=644x461\"]', 123399, 'avto_niva_21214_srochno', 148, NULL, '2022-03-15 18:47:51', NULL, 1),
(149, 7, 13, '722565294', 'https://www.olx.ua/d/obyavlenie/prodatsya-avto-v-garnomu-stan-IDMTOeV.html', 'Продається авто в гарному стані!!!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/i08ra7fvyqa12-UA\\/image;s=644x461\"]', 255611, 'prodaietsya_avto_v_garnomu_stani', 149, NULL, '2022-03-15 18:47:51', NULL, 1),
(150, 7, 13, '742912838', 'https://www.olx.ua/d/obyavlenie/prodatsya-avto-IDOhbz8.html', 'Продається авто!!!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/32th65hqyqua1-UA\\/image;s=644x461\"]', 337877, 'prodaietsya_avto', 150, NULL, '2022-03-15 18:47:51', NULL, 1),
(151, 7, 13, '741749603', 'https://www.olx.ua/d/obyavlenie/aveo-sostoyanie-novogo-avto-IDOciXh.html', 'Aveo, состояние нового авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/a96t7rccn2u53-UA\\/image;s=644x461\"]', 174815, 'aveo_sostoyanie_novogo_avto', 151, NULL, '2022-03-15 18:47:51', NULL, 1),
(152, 7, 13, '741190315', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vaz2109-IDO9Xsw.html', 'Продам авто ваз2109', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/6dwtskkp6ma72-UA\\/image;s=644x461\"]', 32319, 'prodam_avto_vaz2109', 152, NULL, '2022-03-15 18:47:51', NULL, 1),
(153, 7, 13, '736947596', 'https://www.olx.ua/d/obyavlenie/prodam-avto-v-garnomu-stan-IDNS9Jy.html', 'Продам  авто в гарному стані!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/g4ll3ogjv9293-UA\\/image;s=644x461\"]', 246797, 'prodam_avto_v_garnomu_stani', 153, NULL, '2022-03-15 18:47:51', NULL, 1),
(154, 7, 13, '743019619', 'https://www.olx.ua/d/obyavlenie/prodam-avto-uaz-469-IDOhDlp.html', 'Продам авто   УАЗ 469', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ti6y3x5jonyq3-UA\\/image;s=644x461\"]', 52885, 'prodam_avto_uaz_469', 154, NULL, '2022-03-15 18:47:51', NULL, 1),
(155, 7, 13, '737510857', 'https://www.olx.ua/d/obyavlenie/prodam-avto-nissan-almera-IDNUvgp.html', 'Продам авто Nissan Almera', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/a15spy1o0ijg2-UA\\/image;s=644x461\"]', 111646, 'prodam_avto_nissan_almera', 155, NULL, '2022-03-15 18:47:51', NULL, 1);
INSERT INTO `products` (`id`, `area_id`, `url_id`, `pid`, `url`, `name`, `description`, `images`, `price`, `trans`, `sort`, `data`, `created_at`, `updated_at`, `currency_id`) VALUES
(156, 7, 13, '741074721', 'https://www.olx.ua/d/obyavlenie/prodam-avto-vaz-2106-IDO9to5.html', 'Продам авто ВАЗ 2106', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ooju85jdrmju-UA\\/image;s=644x461\"]', 43483, 'prodam_avto_vaz_2106', 156, NULL, '2022-03-15 18:47:51', NULL, 1),
(157, 7, 13, '731510555', 'https://www.olx.ua/d/obyavlenie/avto-na-kazhdyy-den-IDNwljl.html', 'Авто на каждый день.', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/8mui15kmbcwr2-UA\\/image;s=644x461\"]', 42602, 'avto_na_kazhdyy_den', 157, NULL, '2022-03-15 18:47:51', NULL, 1),
(158, 7, 13, '725888901', 'https://www.olx.ua/d/obyavlenie/prodatsya-avto-ford-escort-IDN7KRw.html', 'Продається авто ford escort', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/y7snj9xvpk79-UA\\/image;s=644x461\"]', 69044, 'prodaietsya_avto_ford_escort', 158, NULL, '2022-03-15 18:47:51', NULL, 1),
(159, 7, 13, '743078879', 'https://www.olx.ua/d/obyavlenie/zaz-slavuta-2003-god-vypuska-avto-polnom-hodu-menyayu-na-dachu-IDOhSLd.html', 'ЗАЗ Славута 2003 год выпуска авто полном ходу.Меняю на Дачу  .', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/w7437iqrnyo71-UA\\/image;s=644x461\"]', 41133, 'zaz_slavuta_2003_god_vypuska_avto_polnom_hodu_menyayu_na_dachu', 159, NULL, '2022-03-15 18:47:51', NULL, 1),
(160, 7, 13, '742678313', 'https://www.olx.ua/d/obyavlenie/prodam-avto-na-hodu-IDOgcyt.html', 'Продам  авто на ходу', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/13io1i1q9l461-UA\\/image;s=644x461\"]', 117522, 'prodam_avto_na_hodu', 160, NULL, '2022-03-15 18:47:51', NULL, 1),
(161, 7, 13, '725953352', 'https://www.olx.ua/d/obyavlenie/prodam-avto-audi-q5-IDN81D2.html', 'Продам авто Audi Q5', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ifo9visr41vk2-UA\\/image;s=644x461\"]', 455399, 'prodam_avto_audi_q5', 161, NULL, '2022-03-15 18:47:51', NULL, 1),
(162, 7, 13, '728119954', 'https://www.olx.ua/d/obyavlenie/avto-jeep-grand-cherokee-limited-2016-IDNh7ge.html', 'Авто Jeep Grand Cherokee Limited 2016', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/gxn9fo1hsf2z-UA\\/image;s=644x461\"]', 681630, 'avto_jeep_grand_cherokee_limited_2016', 162, NULL, '2022-03-15 18:47:51', NULL, 1),
(163, 7, 13, '741072163', 'https://www.olx.ua/d/obyavlenie/avto-toyota-alphard-2010-IDO9sIP.html', 'Авто Toyota Alphard 2010', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/93dlg5uucyal2-UA\\/image;s=644x461\"]', 455399, 'avto_toyota_alphard_2010', 163, NULL, '2022-03-15 18:47:51', NULL, 1),
(164, 7, 13, '736767813', 'https://www.olx.ua/d/obyavlenie/prodam-avto-citroen-jumpy-IDNRoXP.html', 'Продам авто Citroen jumpy', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/bkq98de6048v2-UA\\/image;s=644x461\"]', 211540, 'prodam_avto_citroen_jumpy', 164, NULL, '2022-03-15 18:47:51', NULL, 1),
(165, 7, 13, '735294475', 'https://www.olx.ua/d/obyavlenie/prodam-tukson-stan-novogo-avto-IDNLdGj.html', 'Продам Туксон  стан нового авто', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/iz4m0wj7ul9z2-UA\\/image;s=644x461\"]', 831471, 'prodam_tukson_stan_novogo_avto', 165, NULL, '2022-03-15 18:47:51', NULL, 1),
(166, 7, 13, '743077434', 'https://www.olx.ua/d/obyavlenie/avto-legkov-avtomobl-IDOhSnU.html', 'Авто, легкові автомобілі', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/q3kofcoawhfc2-UA\\/image;s=644x461\"]', 39664, 'avto_legkovi_avtomobili', 166, NULL, '2022-03-15 18:47:51', NULL, 1),
(167, 7, 13, '743077340', 'https://www.olx.ua/d/obyavlenie/srochno-avto-za-pol-tseny-dnepr-IDOhSmo.html', 'Срочно авто за пол цены! Днепр!', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/jmy5u8pfdvfq2-UA\\/image;s=644x461\"]', 38195, 'srochno_avto_za_pol_ceny_dnepr', 167, NULL, '2022-03-15 18:47:51', NULL, 1),
(168, 7, 13, '728651212', 'https://www.olx.ua/d/obyavlenie/prodam-avto-na-hodu-polnoe-pereoformlenie-IDNjlsU.html', 'Продам авто на ходу, полное переоформление', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/8aqm596kjm4g1-UA\\/image;s=644x461\"]', 23504, 'prodam_avto_na_hodu_polnoe_pereoformlenie', 168, NULL, '2022-03-15 18:47:51', NULL, 1),
(169, 7, 13, '728133020', 'https://www.olx.ua/d/obyavlenie/avto-skoda-octavia-a5-2-0-td-IDNhaEY.html', 'Авто Skoda Octavia, A5, 2.0 td', NULL, '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/dalmivplyy573-UA\\/image;s=644x461\"]', 352567, 'avto_skoda_octavia_a5_2_0_td', 169, NULL, '2022-03-15 18:47:51', NULL, 1),
(170, 7, 13, '726613852', 'https://www.olx.ua/d/obyavlenie/avto-peugeot-307-IDNaNsg.html', 'Авто Peugeot, 307', 'Автомобиль пригнан с Германии, расстаможен, сертифицирован, в хорошем состоянии.', '[\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/cd7klevrrwl71-UA\\/image;s=644x461\",\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/cd7klevrrwl71-UA\\/image;s=720x335\",\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/qyvz7isidbrg2-UA\\/image;s=720x345\",\"https:\\/\\/ireland.apollo.olxcdn.com:443\\/v1\\/files\\/ety9s71m8kii1-UA\\/image;s=720x343\"]', 4800, 'avto_peugeot_307', 170, '{\"cp\":0.19,\"duration\":3.56,\"memory\":6.88,\"count_db\":76,\"duration_db\":1.68,\"request_count\":1}', '2022-03-15 18:47:51', '2022-03-18 07:08:55', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `stats`
--
-- Создание: Фев 08 2022 г., 09:52
--

DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` int(10) UNSIGNED NOT NULL,
  `rout` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `duration` float DEFAULT NULL,
  `duration_db` float DEFAULT NULL,
  `cp` float DEFAULT NULL,
  `memory` float DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `count_db` int(11) DEFAULT NULL,
  `duration_all` float DEFAULT NULL,
  `duration_db_all` float DEFAULT NULL,
  `cp_all` float DEFAULT NULL,
  `memory_all` float DEFAULT NULL,
  `count_db_all` int(11) DEFAULT NULL,
  `duration_average` float DEFAULT NULL,
  `duration_db_average` float DEFAULT NULL,
  `cp_average` float DEFAULT NULL,
  `memory_average` float DEFAULT NULL,
  `count_db_average` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `percent_duration` float NOT NULL DEFAULT '0',
  `percent_duration_db` float NOT NULL DEFAULT '0',
  `percent_cp` float NOT NULL DEFAULT '0',
  `percent_memory` float NOT NULL DEFAULT '0',
  `percent_count_db` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `stats`
--

INSERT INTO `stats` (`id`, `rout`, `duration`, `duration_db`, `cp`, `memory`, `count`, `count_db`, `duration_all`, `duration_db_all`, `cp_all`, `memory_all`, `count_db_all`, `duration_average`, `duration_db_average`, `cp_average`, `memory_average`, `count_db_average`, `created_at`, `updated_at`, `percent_duration`, `percent_duration_db`, `percent_cp`, `percent_memory`, `percent_count_db`) VALUES
(1, 'main.index', 0.0370021, 0.278016, 0.296401, 3.07489, 1390, 4, 88.5137, 1194.2, 633.099, 4492.84, 76972, 0.0636789, 0.859135, 0.455467, 3.23226, 55, '2022-02-08 10:34:49', '2022-02-21 11:33:36', 0, 0, 0, 0, 0),
(2, 'main.error_page', 0.00588894, 0.00339699, 0.032654, 0.784224, 2069, 1, 397.381, 323.882, 1423.33, 3449.06, 5558, 0.192064, 0.156541, 0.687933, 1.66702, 3, '2022-02-08 10:59:52', '2022-04-05 10:23:26', 0, 0, 0, 0, 0),
(3, 'auth.logout', 0.0138628, 0.00119805, 0.033332, 0.936824, 2, 1, 0.0338327, 0.00234413, 0.073331, 1.64366, 2, 0.0169164, 0.00117207, 0.0366655, 0.821828, 1, '2022-02-08 11:04:10', '2022-02-08 11:05:12', 0, 0, 0, 0, 0),
(4, 'admin.form', 0.0272582, 0.00459194, 0.120946, 0.861728, 623, 1, 39.9401, 469.893, 259.773, 1683, 27186, 0.0641092, 0.754242, 0.416971, 2.70145, 44, '2022-02-08 11:05:50', '2022-04-05 10:23:24', 0, 0, 0, 0, 0),
(5, 'admin.index', 0.0433612, 0.0100422, 0.069999, 2.02198, 373, 10, 105.499, 74.7059, 117.975, 539.005, 1559, 0.28284, 0.200284, 0.316287, 1.44505, 4, '2022-02-08 12:41:44', '2022-03-18 07:40:56', 0, 0, 0, 0, 0),
(6, 'main.columns_table', 7.54843, 7.48643, 1.11641, 2.40459, 16, 2, 19.3861, 11.9897, 14.6309, 35.7001, 32, 1.21163, 0.749355, 0.914432, 2.23126, 2, '2022-02-09 08:03:34', '2022-02-26 16:24:50', 0, 0, 0, 0, 0),
(7, 'admin.products.index', 0.039629, 0.0109556, 0.046666, 2.03798, 1481, 10, 2769.96, 1060.85, 972.452, 4154.71, 12114, 1.87033, 0.716307, 0.656618, 2.80534, 8, '2022-02-09 08:59:53', '2022-03-18 13:36:48', 0, 0, 0, 0, 0),
(8, 'admin.products.add', 0.388022, 0.282015, 1.24415, 2.55047, 53, 2, 12.3703, 8.41498, 49.2274, 108.844, 60, 0.233402, 0.158773, 0.92882, 2.05367, 1, '2022-02-09 09:11:06', '2022-02-22 14:17:54', 0, 0, 0, 0, 0),
(9, 'admin.products.edit', 0.0167232, 0.0051899, 0.033332, 0.96996, 32, 3, 8.83473, 6.78322, 25.7056, 67.0022, 81, 0.276085, 0.211976, 0.803301, 2.09382, 3, '2022-02-09 09:39:01', '2022-03-09 11:40:44', 0, 0, 0, 0, 0),
(10, 'admin.products.displace_sort', 0.0120978, 0.00530148, 0.023332, 0.843832, 29, 8, 8.70374, 6.22989, 25.4199, 55.951, 204, 0.300129, 0.214824, 0.876549, 1.92935, 7, '2022-02-09 09:50:55', '2022-03-10 11:25:00', 0, 0, 0, 0, 0),
(11, 'main.test', 4.29725, 0.194011, 1.37121, 2.84114, 64, 1, 655.223, 12.6066, 65.5137, 150.97, 64, 10.2379, 0.196978, 1.02365, 2.35891, 1, '2022-02-09 12:28:56', '2022-02-10 07:11:03', 0, 0, 0, 0, 0),
(12, 'cron.init', 0.370021, 0.279016, 0.839217, 1.9683, 1, 3, 0.370021, 0.279016, 0.839217, 1.9683, 3, 0.370021, 0.279016, 0.839217, 1.9683, 3, '2022-02-10 14:53:34', NULL, 0, 0, 0, 0, 0),
(13, 'admin.logout', 0.0370021, 0.982056, 0.530403, 3.75253, 19, 65, 0.789046, 13.0969, 8.346, 70.3404, 721, 0.0415287, 0.689308, 0.439263, 3.70213, 38, '2022-02-20 10:45:15', '2022-02-20 10:45:21', 0, 0, 0, 0, 0),
(14, 'admin.auth', 0.0400031, 0.396022, 0.327601, 3.69157, 25, 16, 1.22007, 61.2096, 21.9961, 98.2321, 3729, 0.0488029, 2.44839, 0.879844, 3.92928, 149, '2022-02-20 19:52:28', '2022-02-21 11:34:49', 0, 0, 0, 0, 0),
(15, 'admin.sources.index', 0.257015, 0.19601, 0.402415, 2.48492, 87, 3, 24.0065, 17.9956, 83.8456, 212.972, 261, 0.275937, 0.206846, 0.963743, 2.44795, 3, '2022-02-21 12:13:11', '2022-02-22 06:56:04', 0, 0, 0, 0, 0),
(16, 'admin.sources.add', 0.428024, 0.333019, 0.866223, 2.36423, 21, 1, 4.93727, 3.48223, 21.2016, 49.7247, 21, 0.235108, 0.16582, 1.0096, 2.36784, 1, '2022-02-21 12:14:18', '2022-02-21 13:44:03', 0, 0, 0, 0, 0),
(17, 'admin.sources.edit', 0.33702, 0.251015, 0.713072, 2.37315, 5, 2, 1.34308, 0.987057, 3.4082, 11.8917, 10, 0.268616, 0.197411, 0.68164, 2.37834, 2, '2022-02-21 13:31:39', '2022-02-21 13:48:33', 0, 0, 0, 0, 0),
(18, 'admin.sources.displace_sort', 0.35202, 0.226013, 1.19986, 2.40398, 11, 8, 3.21017, 2.56313, 9.72738, 25.5073, 52, 0.291834, 0.233012, 0.884308, 2.31884, 5, '2022-02-21 13:44:20', '2022-02-21 13:48:04', 0, 0, 0, 0, 0),
(19, 'admin.urls.index', 0.021641, 0.0063839, 0.033332, 1.09783, 484, 6, 360.113, 239.52, 362.585, 1042.79, 2672, 0.744034, 0.494877, 0.749143, 2.15452, 6, '2022-02-21 14:00:50', '2022-03-18 08:37:24', 0, 0, 0, 0, 0),
(20, 'admin.urls.add', 0.0130301, 0.00396705, 0.036665, 0.88056, 25, 2, 8.13588, 5.79158, 23.4186, 54.1462, 50, 0.325435, 0.231663, 0.936743, 2.16585, 2, '2022-02-21 14:18:23', '2022-03-15 18:18:15', 0, 0, 0, 0, 0),
(21, 'admin.urls.edit', 0.013859, 0.00439906, 0.029999, 0.887512, 50, 3, 38.9662, 34.3248, 34.369, 102.821, 150, 0.779323, 0.686496, 0.68738, 2.05641, 3, '2022-02-21 14:28:32', '2022-03-15 18:18:34', 0, 0, 0, 0, 0),
(22, 'admin.areas.index', 0.0144851, 0.00465226, 0.033332, 0.879944, 165, 3, 38.6423, 29.1679, 108.28, 319.11, 498, 0.234196, 0.176775, 0.656244, 1.934, 3, '2022-02-22 07:07:05', '2022-03-15 18:16:00', 0, 0, 0, 0, 0),
(23, 'admin.areas.add', 0.0118291, 0.00362301, 0.026666, 0.828888, 15, 1, 3.161, 2.14676, 13.7011, 34.4932, 15, 0.210733, 0.143118, 0.913404, 2.29955, 1, '2022-02-22 07:07:23', '2022-03-06 18:26:45', 0, 0, 0, 0, 0),
(24, 'admin.areas.displace_sort', 0.013561, 0.00541878, 0.029999, 0.838816, 41, 8, 5.59679, 3.87433, 9.27236, 48.6517, 274, 0.136507, 0.0944958, 0.226155, 1.18663, 7, '2022-02-22 07:21:41', '2022-03-09 10:19:08', 0, 0, 0, 0, 0),
(25, 'admin.areas.edit', 0.622035, 0.52803, 1.66762, 2.57504, 4, 2, 1.42308, 1.09806, 5.99857, 9.7814, 8, 0.35577, 0.274515, 1.49964, 2.44535, 2, '2022-02-22 07:24:25', '2022-03-06 17:08:18', 0, 0, 0, 0, 0),
(26, 'admin.typefields.index', 0.0253222, 0.00497508, 0.043332, 0.905736, 73, 3, 30.6709, 24.8796, 64.2547, 171.061, 219, 0.42015, 0.340816, 0.880202, 2.3433, 3, '2022-02-22 09:24:37', '2022-03-18 07:43:53', 0, 0, 0, 0, 0),
(27, 'admin.typefields.add', 0.413024, 0.315018, 0.908242, 2.52102, 5, 1, 1.32108, 0.927052, 5.24917, 12.2843, 5, 0.264215, 0.18541, 1.04983, 2.45686, 1, '2022-02-22 09:25:20', '2022-02-23 14:32:43', 0, 0, 0, 0, 0),
(28, 'admin.fields.index', 0.0304499, 0.00652409, 0.039999, 1.11331, 200, 7, 80.9327, 65.8913, 134.68, 430.763, 1187, 0.404664, 0.329457, 0.6734, 2.15382, 6, '2022-02-22 09:42:57', '2022-03-18 07:43:45', 0, 0, 0, 0, 0),
(29, 'admin.fields.add', 0.217012, 0.145009, 1.4285, 2.5259, 19, 2, 5.5493, 3.91523, 18.9285, 47.3713, 37, 0.292069, 0.206065, 0.996237, 2.49323, 2, '2022-02-22 09:45:08', '2022-02-22 14:08:41', 0, 0, 0, 0, 0),
(30, 'admin.fields.edit', 0.270016, 0.199011, 0.325836, 2.53687, 6, 3, 2.12212, 1.59009, 5.34864, 15.854, 18, 0.353686, 0.265015, 0.891439, 2.64233, 3, '2022-02-22 10:17:44', '2022-02-22 10:52:56', 0, 0, 0, 0, 0),
(31, 'admin.typefields.edit', 0.576033, 0.51403, 0.889704, 2.53716, 3, 2, 1.10906, 0.901052, 3.09056, 7.48067, 6, 0.369688, 0.300351, 1.03019, 2.49356, 2, '2022-02-22 10:52:23', '2022-02-25 20:17:00', 0, 0, 0, 0, 0),
(32, 'admin.urls.parse', 0.075618, 0.0044148, 0.066665, 0.80704, 164, 1, 97.2593, 61.5201, 162.952, 377.83, 164, 0.593045, 0.375123, 0.993608, 2.30384, 1, '2022-02-22 14:27:28', '2022-03-05 15:13:51', 0, 0, 0, 0, 0),
(33, 'admin.currencies.index', 0.022851, 0.00438285, 0.039999, 0.911488, 35, 3, 12.8263, 11.3389, 12.3397, 51.6308, 105, 0.366464, 0.323968, 0.352563, 1.47517, 3, '2022-02-26 16:47:33', '2022-03-18 07:43:57', 0, 0, 0, 0, 0),
(34, 'admin.currencies.add', 0.600034, 0.532031, 1.47203, 2.55885, 2, 1, 1.49109, 1.35408, 1.77404, 5.114, 2, 0.745543, 0.677039, 0.887021, 2.557, 1, '2022-02-26 16:47:35', '2022-02-26 16:50:51', 0, 0, 0, 0, 0),
(35, 'admin.currencies.edit', 0.455026, 0.380022, 0.768428, 2.57028, 1, 2, 0.455026, 0.380022, 0.768428, 2.57028, 2, 0.455026, 0.380022, 0.768428, 2.57028, 2, '2022-02-26 16:51:17', NULL, 0, 0, 0, 0, 0),
(36, 'admin.products.parse', 0.0764079, 0.00465202, 0.063332, 0.80756, 49, 1, 54.2848, 44.3625, 39.387, 102.413, 49, 1.10785, 0.905356, 0.803817, 2.09005, 1, '2022-02-27 09:39:57', '2022-03-06 14:48:38', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `typefields`
--
-- Создание: Мар 05 2022 г., 20:31
--

DROP TABLE IF EXISTS `typefields`;
CREATE TABLE `typefields` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` float NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `typefields`
--

INSERT INTO `typefields` (`id`, `name`, `trans`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'general', 'general', 1, '2022-03-15 18:47:47', NULL),
(2, 'details', 'details', 2, '2022-03-17 14:45:24', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `urls`
--
-- Создание: Фев 28 2022 г., 10:36
--

DROP TABLE IF EXISTS `urls`;
CREATE TABLE `urls` (
  `id` int(10) UNSIGNED NOT NULL,
  `area_id` int(10) UNSIGNED NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` float NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `urls`
--

INSERT INTO `urls` (`id`, `area_id`, `url`, `trans`, `sort`, `created_at`, `updated_at`, `data`) VALUES
(1, 1, 'https://www.alibaba.com/trade/search', 'url', 1, '2022-02-22 07:14:21', '2022-03-15 08:39:10', '{\"photo\":\"http:\\/\\/parser.v63216hf.beget.tech\\/images\\/nok600.jpg\",\"duration\":14.9199999999999999289457264239899814128875732421875,\"memory\":9.3900000000000005684341886080801486968994140625,\"http_code\":200,\"cp\":0.88000000000000000444089209850062616169452667236328125,\"request_count\":4,\"request_time\":11,\"count_db\":4318,\"duration_db\":0.4699999999999999733546474089962430298328399658203125}'),
(2, 5, 'https://prom.ua/ua/search?search_term=hilti&category=141725', 'url', 2, '2022-02-22 07:25:35', '2022-03-15 08:39:19', '{\"http_code\":200,\"cp\":-0.86999999999999999555910790149937383830547332763671875,\"count\":231,\"duration\":8.71000000000000085265128291212022304534912109375,\"memory\":3.310000000000000053290705182007513940334320068359375,\"count_db\":8706,\"duration_db\":0.83999999999999996891375531049561686813831329345703125}'),
(7, 2, 'https://aliexpress.ru/category/202000020/consumer-electronics.html', 'url', 5, '2022-03-02 11:39:35', '2022-03-15 08:38:55', '{\"http_code\":200,\"cp\":0.2800000000000000266453525910037569701671600341796875,\"duration\":3.970000000000000195399252334027551114559173583984375,\"memory\":7.04999999999999982236431605997495353221893310546875,\"request_time\":3,\"request_count\":1,\"count\":60,\"count_db\":1506,\"duration_db\":0.13000000000000000444089209850062616169452667236328125}'),
(8, 2, 'https://aliexpress.ru/wholesale?catId=&SearchText=Ukraine', 'url', 6, '2022-03-05 14:12:04', '2022-03-14 09:15:41', '{\"http_code\":200,\"cp\":0.320000000000000006661338147750939242541790008544921875,\"duration\":3.3300000000000000710542735760100185871124267578125,\"memory\":5.660000000000000142108547152020037174224853515625,\"request_time\":2,\"request_count\":1,\"count\":66,\"count_db\":1521,\"duration_db\":0.1600000000000000033306690738754696212708950042724609375}'),
(9, 3, 'https://www.ebay.com/b/Computer-Parts-Components/175673/bn_1643095', 'url', 7, '2022-03-06 19:02:45', '2022-03-15 08:38:51', '{\"http_code\":200,\"memory\":2.890000000000000124344978758017532527446746826171875,\"cp\":-0.479999999999999982236431605997495353221893310546875,\"count\":192,\"duration\":14.28999999999999914734871708787977695465087890625,\"count_db\":2626,\"duration_db\":0.40000000000000002220446049250313080847263336181640625,\"request_time\":9,\"request_count\":7}'),
(10, 10, 'https://www.amazon.com/b?node=16225007011', 'url', 8, '2022-03-07 20:03:28', '2022-03-15 08:38:37', '{\"http_code\":200,\"cp\":1.0300000000000000266453525910037569701671600341796875,\"duration\":7.5999999999999996447286321199499070644378662109375,\"memory\":5.019999999999999573674358543939888477325439453125,\"request_count\":8,\"count\":96,\"count_db\":1864,\"duration_db\":0.190000000000000002220446049250313080847263336181640625,\"request_time\":1}'),
(11, 4, 'https://rozetka.com.ua/search/?page=2&section_id=80124&text=стиралка', 'url', 9, '2022-03-15 08:49:42', '2022-03-15 08:56:30', '{\"cp\":0.82,\"duration\":205.45,\"memory\":11.05,\"count_db\":6508,\"duration_db\":133.92,\"request_count\":4,\"count\":144}'),
(12, 6, 'https://bigl.ua/ua/search?search_term=hilti&category=141717', 'url', 10, '2022-03-15 14:37:27', '2022-03-15 15:22:08', '{\"cp\":0.84999999999999997779553950749686919152736663818359375,\"count\":108,\"duration\":4.71999999999999975131004248396493494510650634765625,\"memory\":7.05999999999999960920149533194489777088165283203125,\"count_db\":1836,\"duration_db\":0.25,\"request_count\":4,\"request_time\":1}'),
(13, 7, 'https://www.olx.ua/transport/legkovye-avtomobili/q-авто/', 'url', 11, '2022-03-15 18:18:21', '2022-03-15 18:47:51', '{\"cp\":0.54000000000000003552713678800500929355621337890625,\"count\":176,\"duration\":4.46999999999999975131004248396493494510650634765625,\"memory\":3.930000000000000159872115546022541821002960205078125,\"count_db\":4875,\"duration_db\":0.560000000000000053290705182007513940334320068359375,\"request_count\":4}');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `areas`
--
ALTER TABLE `areas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `areas_sort_index` (`sort`);

--
-- Индексы таблицы `cron`
--
ALTER TABLE `cron`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cron_name_index` (`name`);

--
-- Индексы таблицы `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `currencies_sort_index` (`sort`);

--
-- Индексы таблицы `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fields_sort_index` (`sort`),
  ADD KEY `fields_typefield_id_index` (`typefield_id`),
  ADD KEY `fields_currency_id_index` (`product_id`);

--
-- Индексы таблицы `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_pid_area_id_unique` (`pid`,`area_id`),
  ADD KEY `products_sort_index` (`sort`),
  ADD KEY `products_area_id_index` (`area_id`),
  ADD KEY `products_url_id_index` (`url_id`),
  ADD KEY `products_pid_unique` (`pid`),
  ADD KEY `products_currency_id_index` (`currency_id`);

--
-- Индексы таблицы `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `typefields`
--
ALTER TABLE `typefields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `typefields_sort_index` (`sort`);

--
-- Индексы таблицы `urls`
--
ALTER TABLE `urls`
  ADD PRIMARY KEY (`id`),
  ADD KEY `urls_sort_index` (`sort`),
  ADD KEY `urls_area_id_index` (`area_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `areas`
--
ALTER TABLE `areas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `cron`
--
ALTER TABLE `cron`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=647;

--
-- AUTO_INCREMENT для таблицы `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT для таблицы `stats`
--
ALTER TABLE `stats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `typefields`
--
ALTER TABLE `typefields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `urls`
--
ALTER TABLE `urls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `fields`
--
ALTER TABLE `fields`
  ADD CONSTRAINT `fields_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `fields_typefield_id_foreign` FOREIGN KEY (`typefield_id`) REFERENCES `typefields` (`id`);

--
-- Ограничения внешнего ключа таблицы `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`),
  ADD CONSTRAINT `products_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  ADD CONSTRAINT `products_url_id_foreign` FOREIGN KEY (`url_id`) REFERENCES `urls` (`id`);

--
-- Ограничения внешнего ключа таблицы `urls`
--
ALTER TABLE `urls`
  ADD CONSTRAINT `urls_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
